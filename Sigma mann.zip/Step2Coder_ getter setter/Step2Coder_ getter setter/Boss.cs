﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Step2Coder__getter_setter
{
    public class Boss:Mitarbeiter
    {
        int Mitarbeiter;
        //Basiskonstruktor 
        public Boss() 
        {
             

        }

        //special functions...
        //mitarbeiter_feuern()..gehaltskuerzung()...
    }
}
