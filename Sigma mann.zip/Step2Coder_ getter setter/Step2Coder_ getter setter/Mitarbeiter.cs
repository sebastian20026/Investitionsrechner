﻿using System;

namespace Step2Coder__getter_setter
{
    public class Mitarbeiter
    {
        public string name;
        public int soz_ver_nr;
        private double kontostand;
        public int hierachie_level;
        public int geld;

        // Basiskonstruktor
        public Mitarbeiter()
        {
            // Initialisierung kann hier hinzugefügt werden, falls nötig
        }

        // Konstruktor mit Parametern
        public Mitarbeiter(string _name, double _kontostand)
        {
            name = _name;
            kontostand = _kontostand;
        }

        // Getter für Kontostand
        public double get_kontostand()
        {
            return kontostand;
        }

        // ein setter kann jederzeit einen bestimmten wert setzen
        // hat immer parameter und hat nie einen rueckgabewert
        public void set_kontostand(double _kontostand)
        {
            kontostand = _kontostand;
        }

        // Getter für Sozialversicherungsnummer
        public int get_soz_ver_nr()
        {
            return soz_ver_nr;
        }

        public void set_soz_ver_nr(int get_soz_ver_nr)
        { soz_ver_nr= soz_ver_nr;}
        // Methode, um den Kontostand zu überprüfen
        public bool is_kontostand_below(double amount)
        {
            return kontostand < amount;
        }

        
    }
}
