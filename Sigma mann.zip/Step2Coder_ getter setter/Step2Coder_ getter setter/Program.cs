﻿using System;
using System.Numerics;

namespace Step2Coder__getter_setter
{
    internal class Program
    {
        static void Main(string[] args)

            
        {

            
            Console.Write("Geben Sie den Namen des Mitarbeiters ein: ");
            string name = Console.ReadLine();

            Console.Write("Geben Sie den Kontostand des Mitarbeiters ein: ");
            double kontostand = Convert.ToDouble(Console.ReadLine());

            Mitarbeiter m1 = new Mitarbeiter(name, kontostand);
            

            Console.WriteLine("Der Kontostand von " + m1.name + " ist " + m1.get_kontostand());

            m1.set_kontostand(1000);

            Console.WriteLine("Wie viel mios  hast du");
            Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("was ist deine SV NR");
            m1.set_soz_ver_nr(491154646);
            Convert.ToInt32(Console.ReadLine());
            /*if (m1.is_kontostand_below(10000))
            {
                Console.WriteLine(m1.name + "'s Kontostand ist unter 10.000. Brokie, opfer geh arbeiten!");
            }
            else
            {
                Console.WriteLine(m1.name + "'s Kontostand ist 10.000 oder mehr. Rich!");
            }
            */
        }
    }
}
