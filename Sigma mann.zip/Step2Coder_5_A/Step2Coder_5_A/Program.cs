﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Step2Coder_5_Dictanary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> kundennr = new Dictionary<int, string>();

            kundennr.Add(102, "opfer");
            kundennr.Add(103, "opfer2");
            kundennr.Add(104, "opfer3");

            foreach (KeyValuePair<int, string> kunde in kundennr)
            {
                Console.WriteLine(kunde.Key);
            }

            string[,] ligma = new string[2, 3];

            ligma[0, 0] = "Senf";
            ligma[1, 0] = "Essen";

            ligma[0, 1] = "Passagier";
            ligma[1, 1] = "Flugzeug";

            ligma[0, 2] = "Silvester";
            ligma[1, 2] = "Stalone";

            Console.WriteLine(ligma[0, 1] + " /" + ligma[1, 1]);

        }

    }
}