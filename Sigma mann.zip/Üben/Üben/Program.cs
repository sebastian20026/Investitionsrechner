﻿using System;

namespace Üben
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            double annualinterestrate = 0.08; // Jaehrliche Rendite von 8%
            double currentbalance = 0; // Startsaldo, anfaenglich 0
            double[] monthlydeposits = new double[12];
            double monthlyinterestrate = annualinterestrate / 12;
            int totalyears = 40; // Anlagendauer in jahren

            Console.WriteLine("Bitte geben Sie die monatlichen Einzahlungen für das erste");

            for (int month = 0; month < 12; month++)
            {
                Console.Write("Einzahlung für Monat " + (month + 1) + ": ");
                monthlydeposits[month] = Convert.ToDouble(Console.ReadLine()); // achten auf Readline 
            }
            for (int year = 1; year <= totalyears; year++)
            {
                for (int month = 0; month < 12; month++)

                {


                    currentbalance *= (1 + monthlyinterestrate);

                    currentbalance += monthlydeposits[month];
                }

                Console.WriteLine("Saldo am Ende des Jahres " + year + ": " + currentbalance.ToString("C2"));
            }


            Console.WriteLine("\nEndsaldo nach " + totalyears + " Jahren: " + currentbalance.ToString("C2"));
        }
    }
}
    
