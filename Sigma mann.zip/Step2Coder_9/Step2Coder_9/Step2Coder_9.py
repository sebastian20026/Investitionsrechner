name = input("Wie hei�t du")

print(f"Hallo, { name}!")

zahl1 = input("Zahl1")

zahl2 = input("Zahl2")

print(zahl1+zahl2)