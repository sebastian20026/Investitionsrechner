﻿using System;

class Program
{
    static void Main()
    {
        int auswahl;
        int ok_anzahl;
        double ok_preis = 45.15; // Initialpreis pro "ok"
        int gute_nacht_anzahl;
        double gute_nacht_preis = 4545.45; // Initialpreis pro "gute Nacht Gedicht"

        Console.WriteLine("Willkommen - Drücken Sie 1 für 'ok', 2 für 'gute Nacht' oder 3 zum Beenden");

        while (true)
        {
            Console.Write("Bitte wählen Sie eine Option: ");
            if (!int.TryParse(Console.ReadLine(), out auswahl))
            {
                Console.WriteLine("Ungültige Eingabe, bitte eine Zahl eingeben.");
                continue;
            }

            switch (auswahl)
            {
                case 1:
                    Console.WriteLine("Wie viel 'ok' möchtest du sagen? ");
                    ok_anzahl = Convert.ToInt32(Console.ReadLine());
                    double gesamtOkPreis = ok_anzahl * ok_preis;
                    Console.WriteLine("Du musst " + gesamtOkPreis + " Euro bezahlen\n");
                    break;

                case 2:
                    Console.WriteLine("Wie oft möchtest du ein 'Gute Nacht' Gedicht hören?");
                    gute_nacht_anzahl = Convert.ToInt32(Console.ReadLine());
                    double gesamtGuteNachtPreis = gute_nacht_anzahl * gute_nacht_preis;
                    Console.WriteLine("Du musst " + gesamtGuteNachtPreis + " Euro bezahlen\n");
                    break;

                case 3:
                    Console.WriteLine("Programm beendet.");
                    return; // Verwendet return, um die Methode zu verlassen und das Programm zu beenden

                default:
                    Console.WriteLine("Ungültige Option. Wiederholen Sie Ihre Eingabe.");
                    break;
            }
        }
    }
}
