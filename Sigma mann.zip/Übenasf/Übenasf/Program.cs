﻿using System;
using System.Collections.Generic;

namespace asdf
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Dictionary<int, string> productdetails = new Dictionary<int, string>();

            productdetails.Add(101, "Sigma");
            productdetails.Add(102, "ok");

            foreach (KeyValuePair<int, string> product in productdetails)
            {
                Console.WriteLine(product.Key);
            }


            List<string> namensliste = new List<string>(); // Listen 
              namensliste.Add("Guenther");
              namensliste.Add("Roblox");
              namensliste.Add("f");
              namensliste.Add("ligma"); 

            /*namensliste.Clear(); */ // damit kann ich alles löschen in der liste 


            foreach (string name in namensliste)
            {
                Console.WriteLine(name);

            }

            Console.ReadKey();

            
            Console.WriteLine(namensliste[0]);

            namensliste.Remove("f");

            Console.WriteLine(namensliste[0]);

            Console.ReadKey(); 



            /*string[,] ligma = new string[2, 3];

            ligma[0, 0] = "Senf";
            ligma[1, 0] = "Essen";
            
            ligma[0, 1] = "KEtchup";
            ligma[1, 1] = "Sigma";

            ligma[0, 2] = "asdf";
            ligma[1, 2] = "sadf";

            Console.WriteLine(ligma[0, 0]  + " /" + ligma[1, 0]); */

        }
    }
}