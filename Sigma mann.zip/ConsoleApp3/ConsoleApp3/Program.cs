﻿internal class Program
{
    private static void Main(string[] args)
    {
        int auswahl;

        int i;    // i ist eine zaelvariable .. counter ..

        int noten;

        int frauen;

        int auswahl1;

        double zahl1, zahl2, zahl3;  // deklaration 

        double zahl;

        double summe; //die 3 zahlen summieren 

        double durschnitt; //durschnitt summe = zahl_1 + zahl2 + zahl3; durschnitt = summe / 3;



        summe = 0;

        do

        {


            Console.WriteLine("Willkommen zu meinen Notendurschnittsprogramm");
            Console.WriteLine("Druecke 1 fuer Notendurschnitt fuer 2 oke 3 fuer Exit");

            auswahl = Convert.ToInt32(Console.ReadLine());

            switch (auswahl)
            {
                
               

                case 2:
                    // wie viele frauen 
                    Console.WriteLine("Wie viele Frauen habe ich durschnittlich dieses Wochenende getroffen");
                    frauen = Convert.ToInt32(Console.ReadLine());
                    for (i = 0; i < frauen; i++)
                    {
                        Console.WriteLine("bitte gib mir die anzahl der Damen");
                        zahl = Convert.ToDouble(Console.ReadLine());
                        summe += zahl;

                        Console.WriteLine(summe);

                    }
                    durschnitt = summe / frauen;
                    Console.WriteLine("der durchschnitt betraegt" + durschnitt);

                    break;

                case 3:

                    break;
            }





        } while (auswahl != 3);








    }
}