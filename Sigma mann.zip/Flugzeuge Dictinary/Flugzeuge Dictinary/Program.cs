﻿using System;
using System.Collections.Generic;

namespace Step2Coder_5_A
{
    internal class Program
    {
        static List<string> flughafen = new List<string>(); // Aktiendepot, Inventar, Warenkorb

        static void Main(string[] args)
        {
            intialiueFlughafen();
            manageMenu();
        }

        static void intialiueFlughafen()
        {
            Console.WriteLine("Initialisierung: Geben Sie Flugzeugnamen ein ('x' zum Beenden):");
            string output;
            while ((output = Console.ReadLine()) != "x")
            {
                flughafen.Add(output);
            }
        }

        static void manageMenu()
        {
            string option;
            do
            {
                Console.WriteLine("\nWählen Sie eine Option:");
                Console.WriteLine("1. Flugzeug suchen");
                Console.WriteLine("2. Flugzeug entfernen");
                Console.WriteLine("3. Anzahl der Flugzeuge anzeigen");
                Console.WriteLine("4. Alle Flugzeuge ausgeben");
                Console.WriteLine("5. Programm beenden");
                option = Console.ReadLine();

                switch (option)
                {
                    case "1":
                        searchAircraft();
                        break;

                    case "2":
                        deleteAircraft();
                        break;

                    case "3":
                        countAircraft();
                        break;

                    case "4":
                        printAircraft();
                        break;

                    case "5":
                        Console.WriteLine("Programm wird beendet.");
                        break;

                    default:
                        Console.WriteLine("Ungültige Eingabe. Bitte wiederholen Sie.");
                        break;
                }

            } while (option != "5");
        }

        static void searchAircraft()
        {
            Console.WriteLine("Geben Sie den Namen des zu suchenden Flugzeugs ein:");
            string name = Console.ReadLine();
            if (flughafen.Contains(name))
            {
                Console.WriteLine($"{name} wurde gefunden.");
            }
            else
            {
                Console.WriteLine("Flugzeug nicht gefunden.");
            }
        }

        static void deleteAircraft()
        {
            Console.WriteLine("Welches Flugzeug möchten Sie entfernen?");
            string toremove = Console.ReadLine();
            if (flughafen.Contains(toremove))
            {
                flughafen.Remove(toremove);
                Console.WriteLine($"{toremove} wurde entfernt.");
            }
            else
            {
                Console.WriteLine("Flugzeug nicht gefunden.");
            }
        }

        static void countAircraft()
        {
            Console.WriteLine($"Anzahl der Flugzeuge: {flughafen.Count}");
        }

        static void printAircraft()
        {
            Console.WriteLine("Liste aller Flugzeuge:");
            foreach (var aircraft in flughafen)
            {
                Console.WriteLine(aircraft);
            }
        }
    }
}
