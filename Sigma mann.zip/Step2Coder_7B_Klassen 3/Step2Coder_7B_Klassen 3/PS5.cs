﻿using System;

namespace Step2Coder_7B_Klassen_3
{
    internal class PS5
    {
        public int Speicherplatz;
        public string farbe;
        public int fps;
        public double preis;
        public string aufloesung;
        public string modell;
        public string spiellll;

        // Konstruktor 
        // Immer einen Basiskonstruktor schreiben!

        public PS5() // Basiskonstruktor (kein Parameter)
        {
            Speicherplatz = 254;
            preis = 440.32;
            farbe = "schwarz";
            aufloesung = "4K";
            modell = "Standard";
            spiellll = "Gta";
        }

        // Konstruktor mit Parametern
        public PS5(int speicherplatz, string farbe, int fps, double preis, string aufloesung, string modell)
        {
            Speicherplatz = speicherplatz;
            this.farbe = farbe;
            this.fps = fps;
            this.preis = preis;
            this.aufloesung = aufloesung;
            this.modell = modell;
        }

        // Methoden
        public void spielen(double stunden)
        {
            Console.WriteLine($"Sie spielen {spiellll} für {stunden} Stunden mit {fps} FPS auf einer {aufloesung} Auflösung.");
        }
    }
}






    
