﻿using System;

namespace Step2Coder_7B_Klassen_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PS5 ps51 = new PS5();
            string zocken;
            double stunden;
            Console.WriteLine("Willkommen im Menü");

            Console.WriteLine("Bitte geben Sie an, was Sie spielen wollen:");
            ps51.spiellll = Console.ReadLine();

            Console.WriteLine("Wie viel zahlst du für die PS5?");
            ps51.preis = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Wie viele FPS braucht ihr?");
            ps51.fps = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Welche Farbe soll die PS5 haben?");
            ps51.farbe = Console.ReadLine();

            Console.WriteLine("Wie viel Speicherplatz soll die PS5 haben (in GB)?");
            ps51.Speicherplatz = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Willst du zocken?");
            zocken = Console.ReadLine();

            if (zocken == "ja")
            {
                Console.WriteLine("Wie viele Stunden willst du zocken?");
                stunden = Convert.ToDouble(Console.ReadLine());

                ps51.spielen(stunden);
            }
            else
            {
                Console.WriteLine("Dann zocken Sie nicht.");
            }

            
        }
    }
}

