﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace html_version
{
    internal class Program
    {
        string url = "https://careerfoliospaces.wordpress.com/impressum/Impressum_.html";
        string filepath = 
        static async void Main(string[] args)
        {
            // download the html content 
            string htmlcontent = await Downloadhtmlasync(url);

        }
    }
}
