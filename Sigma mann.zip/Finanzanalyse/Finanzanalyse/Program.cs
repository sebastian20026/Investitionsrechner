﻿using System;
using System.ComponentModel.Design;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Transactions;

namespace Finanzanalyse
{
    internal class Program
    {

        /*public static double eurtousd(double euro) // Definiert eine Methode zur Umrechnung von Euro in Norwegische Kronen.
        {
            return euro * 1.08; // annahme 1 € = 1.08 usd
        }
        public static double usdstoeur(double usd)
        {
            return usd / 1.08; //annahme : 1 usd = 0.93 eur
        }
        // hauptmethode des programms, die bei ausfhührung zuerst aufgerrufen wird.
        static void Main(string[] args)
        {

            Console.WriteLine("Ausgangswaehrung USD oder EUR");  // fordert den benutzer azf die ausgangswaehrung einzugeben.
            string ausgangsrechnung = Console.ReadLine(); // Liest die Benutzereingabe für die Ausgangswaehrung

            Console.WriteLine("Welche Zielwaehrung willst du USD oder EUR"); // fordert den benutzer auf die Zielwaerhung einzugeben.
            string zielrechnung = Console.ReadLine(); // Liest die benutzereingabe für die Zielwaehrung 

            Console.WriteLine("Wie viel brauchst du davon");
            double anzahl = Convert.ToDouble(Console.ReadLine()); // Konvertiert die Eingabe in einen Double-Wert.
            double result; // Variable für das eregebnis der Umrechnung 

            if (ausgangsrechnung == "EUR" && zielrechnung == "USD") 
            {
                result = eurtousd(anzahl); //Ruft die methode zur Umrechnung von Euro zu USD auf.
                Console.WriteLine(anzahl + " EUR sind " + result+" USD"); 
            }
            // Überprüft, ob die eingegebenen Waehrungen EUR zu USD sind.
                else if (ausgangsrechnung == "USD" && zielrechnung == "EUR")
            {
                result = usdstoeur(anzahl); // ruft die methode zur umrechnung von usd zu euro auf.
                Console.WriteLine(anzahl + " usd sind " + result + "EUR");
            }
            else
            {
                Console.WriteLine("Ungueltig Waehrungkombination");
            }
        }
    }
}
*/
        double futurevalue =0;
        double monthlydeposit =  
        double annualreturnrate = 0.08;
        int investmentduration = 40;
