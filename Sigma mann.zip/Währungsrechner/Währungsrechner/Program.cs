﻿using System;
using System.ComponentModel.Design;

namespace Step2Coder_3c
{
    internal class Program // Deklariert eine Klasse namens Program.
    {
        // Definiert eine Methode zur Umrechnung von Euro in Norwegische Kronen.
        public static double EuroToNok(double euro)
        {
            return euro * 10; // Annahme: 1 Euro = 10 NOK
        }

        // Definiert eine Methode zur Umrechnung von Norwegischen Kronen in Euro.
        public static double NokToEuro(double nok)
        {
            return nok / 10; // Annahme: 1 NOK = 0.1 Euro
        }

        // Hauptmethode des Programms, die bei Ausführung zuerst aufgerufen wird.
        static void Main(string[] args)
        {
            // Fordert den Benutzer auf, die Ausgangswährung einzugeben.
            Console.WriteLine("Ausgangswaehrung NOK oder EUR?");
            string Ausgangswaehrung = Console.ReadLine(); // Liest die Benutzereingabe für die Ausgangswährung.

            // Fordert den Benutzer auf, die Zielwährung einzugeben.
            Console.WriteLine("Welche Zielwaehrung willst du NOK oder EUR?");
            string Zielwaehrung = Console.ReadLine(); // Liest die Benutzereingabe für die Zielwährung.

            // Fordert den Benutzer auf, den Betrag einzugeben, der umgerechnet werden soll.
            Console.WriteLine("Wie viel brauchst du davon");
            double Anzahl = Convert.ToDouble(Console.ReadLine()); // Konvertiert die Eingabe in einen Double-Wert.
            double result; // Variable für das Ergebnis der Umrechnung.

            // Überprüft, ob die eingegebenen Währungen EUR zu NOK sind.
            if (Ausgangswaehrung == "EUR" && Zielwaehrung == "NOK")
            {
                result = EuroToNok(Anzahl); // Ruft die Methode zur Umrechnung von Euro zu NOK auf.
                Console.WriteLine($"{Anzahl} EUR sind {result} NOK."); // Gibt das Ergebnis aus.
            }
            // Überprüft, ob die eingegebenen Währungen NOK zu EUR sind.
            else if (Ausgangswaehrung == "NOK" && Zielwaehrung == "EUR")
            {
                result = NokToEuro(Anzahl); // Ruft die Methode zur Umrechnung von NOK zu Euro auf.
                Console.WriteLine($"{Anzahl} NOK sind {result} EUR."); // Gibt das Ergebnis aus.
            }
            else
            {
                // Wird ausgegeben, wenn keine gültige Währungskombination eingegeben wurde.
                Console.WriteLine("Ungueltige Waehrungskombination oder keine Umrechnung notwendig");
            }
        }
    }
}