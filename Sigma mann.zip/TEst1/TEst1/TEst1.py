from flask import Flask, render_template_string, request, redirect, url_for
import json
import statistics

app = Flask(__name__)

numbers = []

@app.route('/')
def index():
    return render_template_string('''
        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Number List Manager</title>
        </head>
        <body>
            <h1>Number List Manager</h1>
            <form action="/add" method="post">
                Zahl: <input type="number" name="number">
                <input type="submit" value="Nummer hinzuf�gen">
            </form>
            <form action="/remove" method="post">
                Zahl: <input type="number" name="number">
                <input type="submit" value="Nummer entfernen">
            </form>
            <p>Aktuelle Liste: {{ numbers }}</p>
            <p><a href="/average">Durchschnitt berechnen</a></p>
            <p><a href="/median">Median berechnen</a></p>
            <p><a href="/save">Liste speichern</a></p>
            <p><a href="/load">Liste laden</a></p>
        </body>
        </html>
    ''', numbers=numbers)

@app.route('/add', methods=['POST'])
def add_number():
    number = int(request.form['number'])
    numbers.append(number)
    return redirect(url_for('index'))

@app.route('/remove', methods=['POST'])
def remove_number():
    number = int(request.form['number'])
    if number in numbers:
        numbers.remove(number)
    return redirect(url_for('index'))

@app.route('/average')
def calculate_average():
    if numbers:
        average = sum(numbers) / len(numbers)
        return f'Der Durchschnitt ist: {average} <br><a href="/">Zur�ck</a>'
    else:
        return 'Die Liste ist leer. <br><a href="/">Zur�ck</a>'

@app.route('/median')
def calculate_median():
    if numbers:
        sorted_numbers = sorted(numbers)
        n = len(sorted_numbers)
        median = (sorted_numbers[n//2] if n % 2 != 0 else (sorted_numbers[n//2 - 1] + sorted_numbers[n//2]) / 2)
        return f'Der Median ist: {median} <br><a href="/">Zur�ck</a>'
    else:
        return 'Die Liste ist leer. <br><a href="/">Zur�ck</a>'

@app.route('/save')
def save_to_file():
    with open('numbers.json', 'w') as file:
        json.dump(numbers, file)
    return 'Die Liste wurde gespeichert. <br><a href="/">Zur�ck</a>'

@app.route('/load')
def load_from_file():
    global numbers
    try:
        with open('numbers.json', 'r') as file:
            numbers = json.load(file)
        return 'Die Liste wurde geladen. <br><a href="/">Zur�ck</a>'
    except FileNotFoundError:
        return 'Keine gespeicherte Liste gefunden. <br><a href="/">Zur�ck</a>'

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')

