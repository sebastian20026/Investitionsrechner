﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace mitarbeiterverwaltung
{
    public class mitarbeiter
    {
        private List<mitarbeiter> mitarbeiter_liste = new List<mitarbeiter>();

        private string vorname;
        private string nachname;
        private string status_im_betrieb;
        private double gehalt;
        private int anzahl_jahre_im_betrieb;

        public mitarbeiter(string vorname, string nachname, string status_im_betrieb, double gehalt, int anzahl_jahre_im_betrieb)
        {
            this.vorname = vorname;
            this.nachname = nachname;
            this.status_im_betrieb = status_im_betrieb;
            this.gehalt = gehalt;
            this.anzahl_jahre_im_betrieb = anzahl_jahre_im_betrieb;
        }

        public string get_vorname() { return vorname; }
        public string get_nachname() { return nachname; }
        public string get_status_im_betrieb() { return status_im_betrieb; }
        public double get_gehalt() { return gehalt; }
        public int get_anzahl_jahre_im_betrieb() { return anzahl_jahre_im_betrieb; }

        public override string ToString()
        {
            return $"{vorname},{nachname},{status_im_betrieb},{gehalt},{anzahl_jahre_im_betrieb}";
        }

        public void mitarbeiter_hinzufuegen(mitarbeiter mitarbeiter)
        {
            mitarbeiter_liste.Add(mitarbeiter);
        }

        public void zeige_mitarbeiter()
        {
            foreach (var mitarbeiter in mitarbeiter_liste)
            {
                Console.WriteLine($"{mitarbeiter.get_vorname()} {mitarbeiter.get_nachname()}, Status: {mitarbeiter.get_status_im_betrieb()}, Gehalt: {mitarbeiter.get_gehalt()}, Jahre im Betrieb: {mitarbeiter.get_anzahl_jahre_im_betrieb()}");
            }
        }

        public double max_gehalt()
        {
            return mitarbeiter_liste.Max(m => m.get_gehalt());
        }

        public double min_gehalt()
        {
            return mitarbeiter_liste.Min(m => m.get_gehalt());
        }

        public double summe_gehalt()
        {
            return mitarbeiter_liste.Sum(m => m.get_gehalt());
        }

        public void speichere_in_datei(string dateiname)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(dateiname))
                {
                    sw.WriteLine("Mitarbeiter Daten:");
                    foreach (var mitarbeiter in mitarbeiter_liste)
                    {
                        sw.WriteLine(mitarbeiter.ToString());
                    }

                    sw.WriteLine();
                    sw.WriteLine($"Maximalgehalt: {max_gehalt()}");
                    sw.WriteLine($"Minimalgehalt: {min_gehalt()}");
                    sw.WriteLine($"Summe der Gehälter: {summe_gehalt()}");
                }
                Console.WriteLine($"Daten wurden in die Datei '{dateiname}' gespeichert.");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"Fehler beim Speichern der Datei: {ex.Message}");
            }
        }

        public void lade_aus_datei(string dateiname)
        {
            if (File.Exists(dateiname))
            {
                try
                {
                    string[] zeilen = File.ReadAllLines(dateiname);
                    mitarbeiter_liste.Clear();
                    foreach (var zeile in zeilen)
                    {
                        if (zeile.Contains(","))
                        {
                            string[] daten = zeile.Split(',');
                            mitarbeiter neuer_mitarbeiter = new mitarbeiter(
                                daten[0],
                                daten[1],
                                daten[2],
                                double.Parse(daten[3]),
                                int.Parse(daten[4])
                            );
                            mitarbeiter_liste.Add(neuer_mitarbeiter);
                        }
                    }
                    Console.WriteLine($"Daten wurden aus '{dateiname}' geladen.");
                }
                catch (IOException ex)
                {
                    Console.WriteLine($"Fehler beim Laden der Datei: {ex.Message}");
                }
            }
            else
            {
                Console.WriteLine("Datei nicht gefunden.");
            }
        }
    }

    class programm
    {
        static void Main(string[] args)
        {
            mitarbeiter verwalter = new mitarbeiter("", "", "", 0, 0);
            verwalter.mitarbeiter_hinzufuegen(new mitarbeiter("Hansi", "Hinterseer", "Aktiv", 75000, 20));
            verwalter.mitarbeiter_hinzufuegen(new mitarbeiter("DJ", "Ötzi", "Inaktiv", 50000, 15));
            verwalter.mitarbeiter_hinzufuegen(new mitarbeiter("Helene", "Fischer", "Aktiv", 100000, 10));
            verwalter.mitarbeiter_hinzufuegen(new mitarbeiter("Andreas", "Gabalier", "Aktiv", 85000, 12));

            verwalter.zeige_mitarbeiter();
            string dateipfad = @"C:\Users\FP2402392\Downloads\archive\test\mitarbeiterdaten.csv";
            verwalter.speichere_in_datei(dateipfad);
            verwalter.lade_aus_datei(dateipfad);
        }
    }
}
