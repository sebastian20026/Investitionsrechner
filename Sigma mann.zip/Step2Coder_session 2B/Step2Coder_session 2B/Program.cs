﻿internal class Program
{
    private static void Main(string[] args)
    {

        string[] gamecharacters = new string[5]; // Deklaration 

        string tmp;

        int auswahl;

        int i;    // i ist eine zaelvariable .. counter ..

        int noten;

        int frauen;

        int auswahl1;

        int countdown;

        int anzahl;

        int[] zahlen = new int[3]; // Deklaration 

        int result;


        double zahl1, zahl2, zahl3;  // deklaration 

        double zahl;

        double summe; //die 3 zahlen summieren 

        double durschnitt; //durschnitt summe = zahl_1 + zahl2 + zahl3; durschnitt = summe / 3;



        summe = 0;

        do

        {


            Console.WriteLine("Willkommen zu meinen Notendurschnittsprogramm");
            Console.WriteLine("Druecke 1 fuer Notendurschnitt fuer 2 Fuer Frauen 3 fuer Exit 4 fuer von 100 bis 1 runterzaehlen"); //immer auf das menue achten wichtig

            auswahl = Convert.ToInt32(Console.ReadLine());

            switch (auswahl)
            {
                case 1:

                    Console.WriteLine("Von wie vielen Noten willst du den Durchschnitt berechnen");
                    noten = Convert.ToInt32(Console.ReadLine());
                    // 1 teil sagt mir wo fange ich an zu zaehlen
                    // 2 Teil wie lange soll ich zaehlen... (Limit)
                    // 3 
                    for (i = 0; i < noten; i++) // statt 3 wie vorher i=0;<3;i++ statt dieser 3 kommt noten rein.
                    {
                        Console.WriteLine("bitte gib mir die zahl");
                        zahl = Convert.ToDouble(Console.ReadLine());

                        summe += zahl;
                        Console.WriteLine(summe);

                    }
                    durschnitt = summe / noten; // statt durschnitt = summe / 3; nimmst du noten da es sonst fehlerhaft ist.
                    Console.WriteLine("der durchschnitt betreagt" + durschnitt);


                    break;

                case 2:
                    // wie viele frauen 
                    Console.WriteLine("Von wie vielen Tagen willst du den Durschnitt berechnen wie viele Frauen du getroffen hast  ");
                    frauen = Convert.ToInt32(Console.ReadLine());
                    for (i = 0; i < frauen; i++)
                    {
                        Console.WriteLine("bitte gib mir die anzahl der Damen pro Tag");
                        zahl = Convert.ToDouble(Console.ReadLine());
                        summe += zahl;

                        Console.WriteLine(summe);

                    }
                    durschnitt = summe / frauen;
                    Console.WriteLine("der durchschnitt betraegt" + durschnitt);

                    break;

                case 3:

                    break;

                case 4: // von 100 nach 1 zaehlen mittels for schleife...
                    Console.WriteLine("Bitte zahl eingeben");
                    countdown = Convert.ToInt32(Console.ReadLine()); // statt countdown könnte ich auch noten 



                    for (i = countdown; i >= 1; i--) // countdown da könnte ich jede andere variable verwenden zb frauen 
                    {
                        Console.WriteLine(i);
                        Thread.Sleep(100);
                    }



                    break;

                case 5:
                    Console.WriteLine("Wie viele Kunden haben Sie");
                    anzahl = Convert.ToInt32(Console.ReadLine());

                    string[] kunden = new string[anzahl];
                    // befuehlen von meinem Array(Datenbank) 
                    for (i = 0; i < anzahl; i++)
                    {
                        Console.WriteLine("bitte gib mir deinen Kunden");
                        kunden[i] = Console.ReadLine();



                    }
                    Console.WriteLine("sortieren");



                    Console.WriteLine("suchen");

                    Console.WriteLine("rueckwaerts");

                    break;
            }







        } while (auswahl != 3);








    }
}