﻿namespace Step2Coder_Blazor.Components.Layout
{
    public class Mitarbeiter
    {
        public string name;
        public string email;
        public string position;

        public Mitarbeiter()
        {

        }


        public Mitarbeiter(string _name,string _email, string _position)
        {
            name = _name;
            email = _email;
            position = _position;
        }
    }
}
