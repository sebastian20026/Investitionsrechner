﻿function showAlter(message) {
    alert(message)
}
< !DOCTYPE html >
    <html>

        <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>BlazorApp</title>
            <base href="/" />
            <link href="css/bootstrap/bootstrap.min.css" rel="stylesheet" />
            <link href="css/app.css" rel="stylesheet" />
            <script src="_framework/blazor.webassembly.js"></script>
            <script>
                window.showAlert = function (message) {
                    alert(message);
        }
            </script>
        </head>

        <body>
            <app>Loading...</app>
        </body>

    </html>
