﻿using System;

namespace Step2Coder_Session3
{
    internal class Program
    {
        //globale Variable
        static double bierpreis;
        static string[] studenten = new string[5]; //Deklaration 
        static void Main(string[] args)
        {
            string[] studenten = new string[5]; //Deklaration = ist eine Deklaration 
            string student;
            int i;
            // Fuellen des Arrys 
            for (i = 0; i < 5; i++)
            {
                Console.WriteLine("gib mir den Studenten");
                studenten[i] = Console.ReadLine();


            }


            //Ausgabe 
            for (i = 0; i < 5; i++)
            {
                Console.WriteLine(studenten[i]);
            }
            // gibt es nicht ueberall.. java, c#, python)
            
            foreach (student in studenten) ;
            Console.WriteLine(student);
        }
    }
}
