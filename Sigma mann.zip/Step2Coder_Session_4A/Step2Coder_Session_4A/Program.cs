﻿


/*string[] array = { "code",  "citrus" };
Console.WriteLine(array[1]);
//citrus

int[] arrays = {1, 2, 3 };
for (int i = 0; i < array.Length; i++)
{
    Console.WriteLine(array[i]);
}*/

/*int[] array = { 1, 2, 3 };
foreach (int wert in array)
{
 Console.WriteLine(wert);
}*/

/*
static int ElementeMultiplizieren(int[] array)
{
    return array[0] * array[1];
}
*/

/*int[,] array = new int[2, 3]; */



/*
Console.WriteLine("Wähle eine Option:");
Console.WriteLine("1: Wert von x ist 5");
Console.WriteLine("2: Wert von 2 x ist 10");
Console.WriteLine("3: Wert von 3 x ist 15");
Console.WriteLine("Gib eine Zahl ein (1, 2, oder 3):");


int x = Convert.ToInt32(Console.ReadLine());

switch(x)
{
    case 1:
        Console.WriteLine("Wert von x ist 5");

        break;

        case 2: Console.WriteLine("Wert von 2 x ist 10");

        break;

        case 3: Console.WriteLine("Wert von 3 x ist 15");

        break;

    default: Console.WriteLine("BYe");
        break;
        



}
*/
/*using System;

void funktion2(string a)
{
    Console.WriteLine("Ich hab {0 mitgegeben", a);
}

*/

/*using System;

public void hello()
{ Console.WriteLine("Hello bro");
}*/


/*using System;

int funktion4 (int a, int b)
{

    if (a > b)
    {
        return a;
    }
    else
    {
        return b;
    }
}
int groessereZahl = p.funktion4(3, 8);
Console.WriteLine("der groesste wert, ist {0}", groessereZahl);

bool funktion5(int a, int b){
    if (a == b) {
    return true;
       }
        return false;
} */
/*
using System;
using System.ComponentModel.Design;

namespace Step2Coder_3c
{
    internal class Program // Deklariert eine Klasse namens Program.
    {
        // Definiert eine Methode zur Umrechnung von Euro in Norwegische Kronen.
        public static double EuroToNok(double euro)
        {
            return euro * 10; // Annahme: 1 Euro = 10 NOK
        }

        // Definiert eine Methode zur Umrechnung von Norwegischen Kronen in Euro.
        public static double NokToEuro(double nok)
        {
            return nok / 10; // Annahme: 1 NOK = 0.1 Euro
        }

        // Hauptmethode des Programms, die bei Ausführung zuerst aufgerufen wird.
        static void Main(string[] args)
        {
            // Fordert den Benutzer auf, die Ausgangswährung einzugeben.
            Console.WriteLine("Ausgangswaehrung NOK oder EUR?");
            string Ausgangswaehrung = Console.ReadLine(); // Liest die Benutzereingabe für die Ausgangswährung.

            // Fordert den Benutzer auf, die Zielwährung einzugeben.
            Console.WriteLine("Welche Zielwaehrung willst du NOK oder EUR?");
            string Zielwaehrung = Console.ReadLine(); // Liest die Benutzereingabe für die Zielwährung.

            // Fordert den Benutzer auf, den Betrag einzugeben, der umgerechnet werden soll.
            Console.WriteLine("Wie viel brauchst du davon");
            double Anzahl = Convert.ToDouble(Console.ReadLine()); // Konvertiert die Eingabe in einen Double-Wert.
            double result; // Variable für das Ergebnis der Umrechnung.

            // Überprüft, ob die eingegebenen Währungen EUR zu NOK sind.
            if (Ausgangswaehrung == "EUR" && Zielwaehrung == "NOK")
            {
                result = EuroToNok(Anzahl); // Ruft die Methode zur Umrechnung von Euro zu NOK auf.
                Console.WriteLine($"{Anzahl} EUR sind {result} NOK."); // Gibt das Ergebnis aus.
            }
            // Überprüft, ob die eingegebenen Währungen NOK zu EUR sind.
            else if (Ausgangswaehrung == "NOK" && Zielwaehrung == "EUR")
            {
                result = NokToEuro(Anzahl); // Ruft die Methode zur Umrechnung von NOK zu Euro auf.
                Console.WriteLine($"{Anzahl} NOK sind {result} EUR."); // Gibt das Ergebnis aus.
            }
            else
            {
                // Wird ausgegeben, wenn keine gültige Währungskombination eingegeben wurde.
                Console.WriteLine("Ungueltige Waehrungskombination oder keine Umrechnung notwendig");
            }
        }
    }
} */

