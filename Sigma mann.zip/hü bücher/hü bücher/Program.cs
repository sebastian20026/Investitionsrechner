﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace Bibliotheksverwaltung
{
    internal class Program
    {
        static List<Book> books = new List<Book>();
        const string filePath = "books.txt";

        static void Main(string[] args)
        {
            LoadBooksFromFile();
            Displaybooks(); // Zeige beim Start die vorhandenen Bücher an
            string choice;
            do
            {
                Console.WriteLine("\n=====================================");
                Console.WriteLine("Willkommen im Bibliotheksverwaltungssystem");
                Console.WriteLine("=====================================");
                Console.WriteLine("1. Buch hinzufügen und anzeigen");
                Console.WriteLine("2. Buch suchen und löschen");
                Console.WriteLine("3. Bücher nach Autor auflisten");
                Console.WriteLine("4. Programm beenden");
                Console.WriteLine("=====================================");
                Console.Write("Bitte wählen Sie eine Option (1-4): ");
                choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        addbook();
                        Displaybooks();
                        break;
                    case "2":
                        SearchAndDeleteBook();
                        break;
                    case "3":
                        ListBooksByAuthor();
                        break;
                    case "4":
                        SaveBooksToFile();
                        Console.WriteLine("Programm wird beendet.");
                        break;
                    default:
                        Console.WriteLine("Ungültige Eingabe, bitte versuchen Sie es erneut.");
                        break;
                }

                if (choice != "4")
                {
                    Console.WriteLine("\nDrücken Sie eine beliebige Taste, um zum Menü zurückzukehren...");
                    Console.ReadKey();
                }
            } while (choice != "4");
        }

        static void LoadBooksFromFile()
        {
            if (File.Exists(filePath))
            {
                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    var book = Book.FromString(line);
                    if (book != null)
                    {
                        books.Add(book);
                    }
                }
            }
        }

        static void SaveBooksToFile()
        {
            var lines = books.Select(b => b.ToString()).ToArray();
            File.WriteAllLines(filePath, lines);
        }

        static void addbook()
        {
            Console.Clear();
            Console.WriteLine("=====================================");
            Console.WriteLine("Neues Buch hinzufügen");
            Console.WriteLine("=====================================");
            Console.Write("Titel: ");
            string title = Console.ReadLine();
            Console.Write("Autor: ");
            string author = Console.ReadLine();
            Console.Write("ISBN: ");
            string isbn = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(author) || string.IsNullOrWhiteSpace(isbn))
            {
                Console.WriteLine("Fehler: Alle Felder müssen ausgefüllt werden.");
                return;
            }

            books.Add(new Book(title, author, isbn));
            Console.WriteLine("Buch erfolgreich hinzufügt");
        }

        static void Displaybooks()
        {

            
                {
                Console.Clear();
                Console.WriteLine("=====================================");
                Console.WriteLine("Liste der Bücher");
                Console.WriteLine("=====================================");

                if (books.Count == 0)
                {
                    Console.WriteLine("Es sind keine Bücher vorhanden.");
                }
                else
                {
                    foreach (var book in books)
                    {
                        book.Display();
                    }

                }
            }
        }

        static void SearchAndDeleteBook()
        {
            Console.Clear();
            Console.WriteLine("=====================================");
            Console.WriteLine("Buch suchen und löschen");
            Console.WriteLine("=====================================");
            Console.Write("Geben Sie den Titel oder Autor des zu suchenden Buches ein: ");
            string search = Console.ReadLine();

            var foundBooks = books.Where(b => b.Title.Contains(search, StringComparison.OrdinalIgnoreCase) || b.Author.Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();

            if (foundBooks.Count == 0)
            {
                Console.WriteLine("Kein Buch mit den angegebenen Informationen gefunden.");
                return;

            }
            Console.WriteLine("Gefundene Buecher");
            foreach (var book in foundBooks)
            {
                book.Display();
            }
            Console.Write("Geben Sie die ISBN des zu löschenden Buches ein:");
            string isbn = Console.ReadLine();

            var bookToDelete = books.FirstOrDefault(b => b.ISBN == isbn);
            if (bookToDelete != null)
            {
                books.Remove(bookToDelete);
                Console.WriteLine("Buch erfolgreich gelöscht");

            }
            else
            {
                Console.WriteLine("Buch nicht gefunden");
            }
        }
            static void ListBooksByAuthor()
        {
            Console.Clear();
            Console.WriteLine("=====================================");
            Console.WriteLine("Bücher nach Autor auflisten");
            Console.WriteLine("=====================================");
            Console.Write("Geben Sie den Namen des Autors ein: ");
            string author = Console.ReadLine();

            var authorBooks = books.Where(b => b.Author.Equals(author, StringComparison.OrdinalIgnoreCase)).ToList();

            if (authorBooks.Count == 0)
            {
                Console.WriteLine($"Keine Bücher des Autors {author} gefunden.");

            }
            else
            {
                Console.WriteLine($"Bücher von {author}:");
                foreach (var book in authorBooks)
                { book.Display();


                }
            }
        }
    }
}