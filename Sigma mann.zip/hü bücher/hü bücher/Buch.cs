﻿using System;

namespace Bibliotheksverwaltung
{
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }

        public Book() { }

        public Book(string title, string author, string isbn)
        {
            Title = title;
            Author = author;
            ISBN = isbn;
        }

        public void Display()
        {
            Console.WriteLine($"Titel: {Title}, Autor: {Author}, ISBN: {ISBN}");
        }

        public override string ToString()
        {
            return $"{Title}|{Author}|{ISBN}";
        }

        public static Book FromString(string bookString)
        {
            string title = bookString.Substring(0, bookString.IndexOf("|"));
            bookString = bookString.Substring(bookString.IndexOf("|") + 1);
            string author = bookString.Substring(0, bookString.IndexOf("|"));
            string isbn = bookString.Substring(bookString.IndexOf("|") + 1);

            return new Book(title, author, isbn);
        }
    }
}
