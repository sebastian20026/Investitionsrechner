﻿internal class Program
{
    private static void Main(string[] args)
    {

        string[] gamecharacters = new string[5]; // Deklaration 

        string tmp;

        string gesuchterKunde;

        int index;

        int auswahl;

        int i;    // i ist eine zaelvariable .. counter ..

        int noten;

        int frauen;

        int auswahl1;

        int countdown;

        int anzahl;

        int[] zahlen = new int[3]; // Deklaration 

        int result;


        double zahl1, zahl2, zahl3;  // deklaration 

        double zahl;

        double summe; //die 3 zahlen summieren 

        double durschnitt; //durschnitt summe = zahl_1 + zahl2 + zahl3; durschnitt = summe / 3;

       

        summe = 0;
        
    do

    { 


        Console.WriteLine("Willkommen zu meinen Kundenprogramm ");
        Console.WriteLine("Druecke 1 fuer kundeneingabe fuer 2 Fuer sortieren 3 fuer Exit 4 fuer von 100 bis 1 runterzaehlen 5 Kundenseite"); //immer auf das menue achten wichtig

        auswahl = Convert.ToInt32(Console.ReadLine());

        switch (auswahl)
        {
        case 1:

        Console.WriteLine("wie viele kunden haben Sie");
        noten= Convert.ToInt32(Console.ReadLine());
        // 1 teil sagt mir wo fange ich an zu zaehlen
        // 2 Teil wie lange soll ich zaehlen... (Limit)
        // 3 
        for (i=0;i<noten;i++) // statt 3 wie vorher i=0;<3;i++ statt dieser 3 kommt noten rein.
        {
        Console.WriteLine("bitte gib mir die zahl");
        zahl = Convert.ToDouble(Console.ReadLine());

        summe += zahl;
        Console.WriteLine(summe);
             
        }
            durschnitt = summe / noten; // statt durschnitt = summe / 3; nimmst du noten da es sonst fehlerhaft ist.
            Console.WriteLine("der durchschnitt betreagt" + durschnitt);


        break;

        case 2:
        break;

        case 3:

        break;

        case 4:

        Console.WriteLine("mulitplier");
        Console.WriteLine("enter number to start multiplying");
        countdown = Convert.ToInt32(Console.ReadLine());
        result = countdown;

        for (i = countdown;i > 0; i--)
        {

        result = countdown * i;
        Console.WriteLine($"{countdown} * {i} = {result}");
        }

        break;

        case 5:
        Console.WriteLine("Wie viele Kunden haben Sie");
        anzahl = Convert.ToInt32(Console.ReadLine());

        string[] kunden = new string[anzahl]; 
        // befuehlen von meinem Array(Datenbank) 
        for(i=0; i<anzahl; i++)
        {
        Console.WriteLine("bitte gib mir deinen Kunden");
        kunden[i] = Console.ReadLine();

          
                    
        }
        Console.WriteLine("sortieren");

        Array.Sort(kunden);
                        for (i = 0; i < anzahl; i++)
                        {

                        Console.WriteLine(kunden[i]);
                        }

        Console.WriteLine (" welche kunden möchten sie suchen");
        gesuchterKunde = Console.ReadLine();



        Console.WriteLine("Kundenliste rückwärts:");
                        for (i = anzahl - 1; i >= 0; i--)
                        {
                       Console.WriteLine(kunden[i]);
                        }

                        break;
        }        
         






        }while (auswahl != 3);








    }
}