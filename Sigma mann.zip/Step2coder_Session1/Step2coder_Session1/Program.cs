﻿
// 

string name; //string ist fuer woerter und variablen immer klein 

string wheredoyoulive;
int age;  //interger bedeutet ganze zahlen 

int bier;

int cookies;

int beef;

string hour;

string howareyou;

int sister;

int cars;

string pin;

string street;

double weight;  // Datentyp 

Console.WriteLine("what is your weight");
weight= Convert.ToDouble(Console.ReadLine());
Console.WriteLine(weight);

Console.WriteLine("ok");

Console.WriteLine("Leberkäs");

Console.WriteLine("Halli Hallo!");

Console.WriteLine("hallo");

Console.WriteLine("Whats your name");
name = Console.ReadLine();

Console.WriteLine("where do äää  you live");
wheredoyoulive = Console.ReadLine();

Console.WriteLine("how old are you? ");
age = Convert.ToInt32(  Console.ReadLine() );

Console.WriteLine("how many sisters do you have");
sister = Convert.ToInt32( Console.ReadLine() );


Console.WriteLine("how many cars do you have");
cars = Convert.ToInt32( Console.ReadLine() );

if (age<16)
{
    Console.WriteLine("sorry, no beer :(");
}

if (age == 99)
{ Console.WriteLine("free beer for you");

}
else
{ 

    Console.WriteLine("how many beer´s do you wanna drink");

}


if (sister<5)
{
        Console.WriteLine("awesome");
}

if (sister == 6)
{
    Console.WriteLine("You got a problem bro");


}
else
{
    Console.WriteLine("can i meet them");
}


if (cars < 4)
{
    Console.WriteLine("your my hero");
}

if (cars == 8)
{ Console.WriteLine("can i be your bro");
}


else
{
      Console.WriteLine("can i drive them");
}


    beginning:
    Console.WriteLine("what is your pin");
    pin = Console.ReadLine();

if (pin.Equals("1234"))
{
        Console.WriteLine("pin correct");
}
else
{
        Console.WriteLine("sorry wrong try again");
        goto beginning;
}
streetname:
Console.WriteLine("on which street do you live");
street = Console.ReadLine();

if (!street.Equals("zeisigstrasse_13"))
{
    Console.WriteLine("street is correct");
}
else
{
    Console.WriteLine("your street is not on my map try again");
    goto streetname;
}
    
if (age==98)
{
    Console.WriteLine("du alter opa");
    Environment.Exit(0);
}
else
{
    Console.WriteLine("du bist doch nicht so alt");
    goto oldman;
}
oldman: Console.WriteLine("bye");

Console.WriteLine("how many beers do you wanna drink? ");
bier = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("how much cookies do you want");
cookies = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("how much kg beef do you wanna eat");
beef = Convert.ToInt32(Console.ReadLine());


// Console.WriteLine("Welcome to my App" + name +"how are you");

Console.WriteLine("how are you");
howareyou = Console.ReadLine();
