﻿using System;
using System.Dynamic;

namespace Step2CoderSession3_B
{
    internal class Program
    {
        
         public static void average_iq()
         {
             int auswahl;

             double zahl1, zahl2, zahl3, avg;

             Console.WriteLine("gib mir die erste zahl");
             zahl1 = Convert.ToDouble(Console.ReadLine());

             Console.WriteLine("gib mir die zweite zahl");
             zahl2 = Convert.ToDouble(Console.ReadLine());

             Console.WriteLine("gib mir die dritte zahl");
             zahl3 = Convert.ToDouble(Console.ReadLine());

             avg = (zahl1 + zahl2 + zahl3) / 3;

             Console.WriteLine("der durschnittbetraegt" + avg);
         }




        //print_menue(); // funktionsaufruf function call 
        // mit rueckgabewert 
        public static double average_iq2()
        {
            
            double zahl1, zahl2, zahl3, avg;

            Console.WriteLine("gib mir die erste zahl");
            zahl1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("gib mir die zweite zahl");
            zahl2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("gib mir die dritte zahl");
            zahl3 = Convert.ToDouble(Console.ReadLine());

            avg = (zahl1 + zahl2 + zahl3) / 3;

            //Console.WriteLine("der durschnittbetraegt" + avg);
            return avg; 


        }


        public static double average_iq3(double zahl1, double zahl2, double zahl3)
        {

            
            double avg;

            avg = (zahl1 + zahl2 + zahl3) / 3;

            return avg;



        }


        static void Main(string[] args)
        {
            double erg;
            double zahl1, zahl2, zahl3;

            average_iq(); // mit void ohne rueckgabewert.. 

            
            
            
            
            
            
            
            
            //average_iq2();   // der aufruf einer void funktion

            erg = average_iq2(); // aufruf mit rueckgabewert
            Console.WriteLine("der Durchschnitt betraegt " + erg);







            //3 Variante 
            Console.WriteLine("gib mir die erste zahl");
            zahl1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("gib mir die zweite zahl");
            zahl2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("gib mir die dritte zahl");
            zahl3 = Convert.ToDouble(Console.ReadLine());

            erg= average_iq3(zahl1,zahl2,zahl3);  // beim funktions 

            Console.WriteLine("der Durchschnitt betraegt " + erg);


        }


    }
 }