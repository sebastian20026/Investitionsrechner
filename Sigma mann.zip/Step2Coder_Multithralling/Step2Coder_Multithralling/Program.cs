﻿```csharp
using System;
using System.Threading;
using System.IO;
using System.Runtime.Intrinsics.Arm;
using System.Threading.Channels;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace Step2Coder_Multithralling
{
    internal class Program
    {
        // Methode zum Schreiben von Großbuchstaben
        static public void schreibegrossbuchstaben()
        {
            int i;
            for (i = 0; i < 10; i++)
            {
                Console.WriteLine("A" + i);  // Ausgabe eines Großbuchstabens mit Index
                Thread.Sleep(250);           // Pause für 250 Millisekunden
            }
        }

        // Methode zum Schreiben von Kleinbuchstaben
        static public void schreibekleinbuchstaben()
        {
            int i;
            for (i = 0; i < 10; i++)
            {
                Console.WriteLine((char)('a' + i));  // Ausgabe eines Kleinbuchstabens mit Index
                Thread.Sleep(250);                  // Pause für 250 Millisekunden
            }
        }

        static void Main(string[] args)
        {
            // Erstellung von Tasks für Groß- und Kleinbuchstaben
            Task task1 = new Task(() => { schreibegrossbuchstaben(); });
            Task task2 = new Task(() => { schreibekleinbuchstaben(); });

            // Start der Tasks
            task1.Start();
            task2.Start();

            // Warten, bis task1 abgeschlossen ist
            Task.WaitAll(task1);

            // Warten auf Abschluss von task1 und task2
            task1.Wait();
            task2.Wait();

            int ergebnis;

            // Lambda-Ausdruck zum Quadrieren einer Zahl
            Func<int, int> quadrieren = x => x * x;

            // Anwendung des Lambda-Ausdrucks
            ergebnis = quadrieren(5); // Ergebnis wird 25 sein 
            Console.WriteLine(ergebnis);

            // Fehlerbehandlung, Exception Handling
            string filepath = @"C:\Users\FP2402392\Downloads\test.txt"; // Dateipfad

            try
            {
                // Versuch, den Inhalt der Datei zu lesen
                string content = File.ReadAllText(filepath);
                Console.WriteLine("file content");
                Console.WriteLine(content);
            }
            catch (Exception ex)
            {
                // Fehlermeldung, wenn etwas schiefgeht
                Console.WriteLine("da geht wos nd" + ex.Message);
            }

            // Threads für Groß- und Kleinbuchstaben
            Thread prozess1 = new Thread(new ThreadStart(schreibegrossbuchstaben));
            Thread prozess2 = new Thread(new ThreadStart(schreibekleinbuchstaben));

            // Start der Threads
            prozess1.Start();
            prozess2.Start();

            // Warten, bis prozess1 abgeschlossen ist
            prozess1.Join();

            // Abfangen und Behandeln von Benutzereingaben
            try
            {
                Console.WriteLine("Enter a number (1, 2 or 3):");
                string input = Console.ReadLine();
                int number = int.Parse(input);

                // Verarbeitung der Benutzereingabe
                switch (number)
                {
                    case 1:
                        Console.WriteLine("you entered one");
                        break;
                    case 2:
                        Console.WriteLine("you entered two ");
                        break;
                    case 3:
                        Console.WriteLine("you entered three");
                        break;
                    default:
                        Console.WriteLine("invalid number entered");
                        break;
                }
            }
            catch (Exception ex)
            {
                // Fehlermeldung, wenn etwas schiefgeht
                Console.WriteLine("sa geht was nd" + ex.Message);
            }
        }
    }
}
```