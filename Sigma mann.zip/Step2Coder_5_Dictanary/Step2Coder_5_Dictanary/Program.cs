﻿using System;
using System.Collections.Generic;

namespace Step2Coder_5_Dictanary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> kundennr = new Dictionary<int, string>();

            kundennr.Add(102, "opfer");
            kundennr.Add(103, "opfer2");
            kundennr.Add(104, "Opfer3");

            string[,] bester_kunde = new string[2, 3];


            foreach (KeyValuePair<int, string> kunde in kundennr) 
            { 
            Console.WriteLine(kunde.Key);
            }


            bester_kunde[0, 0] = "Senf";
            bester_kunde[1, 0] = "Essen";

            bester_kunde[0, 1] = "Passagier";
            bester_kunde[1, 1] = "Flugzeug";

            bester_kunde[0, 2] = "Silvester";
            bester_kunde[1, 2] = "Stalone";

            Console.WriteLine(bester_kunde[0, 0] +" /" + bester_kunde[1, 0]);


        }

    }
}
