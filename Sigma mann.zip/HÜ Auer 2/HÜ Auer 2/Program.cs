﻿using System;
using System.Collections.Generic;

class SportStatistik
{
    static void Main()
    {
        int anzahl;
        List<double> leistungen = new List<double>();
        double besteZeit, hoechsterWert, start, ende;
        int anzahlImBereich;

        Console.WriteLine("Geben Sie die Anzahl der Versuche ein:");
        anzahl = int.Parse(Console.ReadLine());

        for (int i = 0; i < anzahl; i++)
        {
            Console.WriteLine($"Leistung für Versuch {i + 1}:");
            leistungen.Add(double.Parse(Console.ReadLine()));
        }

        leistungen.Sort();
        besteZeit = leistungen.Min();
        hoechsterWert = leistungen.Max();

        string option = "";
        while (option != "E")
        {
            Console.WriteLine("\nWählen Sie eine Analyseoption:");
            Console.WriteLine("A) Beste Zeit anzeigen");
            Console.WriteLine("B) Höchster Wert anzeigen");
            Console.WriteLine("C) Sortierte Werte anzeigen");
            Console.WriteLine("D) Anzahl der Werte in einem Bereich anzeigen");
            Console.WriteLine("E) Programm beenden");
            option = Console.ReadLine().ToUpper();

            switch (option)
            {
                case "A":
                    Console.WriteLine($"Beste Zeit: {besteZeit}");
                    break;
                case "B":
                    Console.WriteLine($"Höchster Wert: {hoechsterWert}");
                    break;
                case "C":
                    Console.WriteLine("Sortierte Werte:");
                    foreach (var leistung in leistungen)
                    {
                        Console.WriteLine(leistung);
                    }
                    break;
                case "D":
                    Console.WriteLine("Geben Sie den Bereich an (Startwert und Endwert):");
                    start = double.Parse(Console.ReadLine());
                    ende = double.Parse(Console.ReadLine();
                    anzahlImBereich = leistungen.Count(x => x >= start && x <= ende);
                    Console.WriteLine($"Anzahl der Werte im Bereich ({start}, {ende}): {anzahlImBereich}");
                    break;
                case "E":
                    Console.WriteLine("Programm wird beendet...");
                    break;
                default:
                    Console.WriteLine("Ungültige Eingabe, bitte wählen Sie eine der gegebenen Optionen.");
                    break;
            }
        }
    }
}
