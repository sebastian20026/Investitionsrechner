﻿using System;

namespace Step2Coder_8_Vererbung
{
    public class Human
    {
        public string Name; // Name des Menschen
        public int Augen; // Anzahl der Augen
        public int Beine; // Anzahl der Beine
        public string Haarfarbe; // Haarfarbe
        public string Hautfarbe; // Hautfarbe
        private string id; // private ID, kann nur innerhalb der Klasse verwendet werden
        public double Lebenspunkte; // Lebenspunkte des Menschen

        public Human() // Standardkonstruktor
        {
            Name = "Unbekannt";
            Augen = 2;
            Beine = 2;
            Haarfarbe = "Unbekannt";
            Hautfarbe = "Unbekannt";
            Lebenspunkte = 100;
        }

        public Human(string name, string hautfarbe) // Konstruktor mit Parametern
        {
            this.Name = name;
            Augen = 2;
            Beine = 2;
            Haarfarbe = "Unbekannt";
            Hautfarbe = hautfarbe;
            Lebenspunkte = 100;
        }

        public void Fight()
        {
            Console.WriteLine($"{Name} kämpft."); // Anzeige, dass der Mensch kämpft
        }

        public void PrintData()
        {
            Console.WriteLine($"Name: {Name}, Augen: {Augen}, Beine: {Beine}, Haarfarbe: {Haarfarbe}, Hautfarbe: {Hautfarbe}, Lebenspunkte: {Lebenspunkte}"); // Ausgabe der Eigenschaften
        }
    }
}
