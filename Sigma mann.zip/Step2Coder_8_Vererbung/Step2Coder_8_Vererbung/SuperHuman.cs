﻿using System;

namespace Step2Coder_8_Vererbung
{
    public class SuperHuman : Human
    {
        public string SuperPower; // Superkraft des Supermenschen

        public SuperHuman() : base()
        {
            SuperPower = "Unbekannt";
            Lebenspunkte = 200; // SuperHumans haben mehr Lebenspunkte
        }

        public SuperHuman(string name, string hautfarbe, string superPower) : base(name, hautfarbe)
        {
            this.SuperPower = superPower;
            Lebenspunkte = 200; // SuperHumans haben mehr Lebenspunkte
        }

        public void UseSuperPower()
        {
            Console.WriteLine($"{Name} nutzt seine Superkraft: {SuperPower}."); // Anzeige der Superkraft
        }
    }
}
