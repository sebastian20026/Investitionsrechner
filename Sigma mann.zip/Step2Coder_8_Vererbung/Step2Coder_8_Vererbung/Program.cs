﻿using System;

namespace Step2Coder_8_Vererbung
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Instanziierung der Objekte
            Human dieter = new Human("Dieter", "Weiß");
            SuperHuman hansiHinterseer = new SuperHuman("Hansi Hinterseer", "Schwarz", "Fliegen");

            Console.WriteLine("Kampf beginnt!");
            dieter.PrintData(); // Daten von Dieter anzeigen
            hansiHinterseer.PrintData(); // Daten von Hansi Hinterseer anzeigen

            // Eingabe der Lebenspunkte-Verluste
            Console.WriteLine("Geben Sie an, wie viele Lebenspunkte Human bei einer Attacke verliert: ");
            double humanAttack = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Geben Sie an, wie viele Lebenspunkte SuperHuman bei einer Attacke verliert: ");
            double superHumanAttack = Convert.ToDouble(Console.ReadLine());

            // Kampf ausführen
            GameController.Fight(dieter, hansiHinterseer, humanAttack, superHumanAttack);

            Console.WriteLine("Kampf beendet!");
        }
    }
}
