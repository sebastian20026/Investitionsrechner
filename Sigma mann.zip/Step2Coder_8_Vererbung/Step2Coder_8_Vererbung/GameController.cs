﻿using System;

namespace Step2Coder_8_Vererbung
{
    public static class GameController
    {
        public static void Fight(Human h, SuperHuman s, double humanAttack, double superHumanAttack)
        {
            Console.WriteLine($"{h.Name} kämpft jetzt gegen {s.Name}, der die Superkraft {s.SuperPower} hat.");
            h.Fight();
            s.UseSuperPower();

            // Schaden berechnen
            h.Lebenspunkte -= superHumanAttack;
            s.Lebenspunkte -= humanAttack;

            Console.WriteLine($"{h.Name} verliert {superHumanAttack} Lebenspunkte und hat jetzt {h.Lebenspunkte} Lebenspunkte.");
            Console.WriteLine($"{s.Name} verliert {humanAttack} Lebenspunkte und hat jetzt {s.Lebenspunkte} Lebenspunkte.");

            // Ergebnis des Kampfes
            if (h.Lebenspunkte > s.Lebenspunkte)
            {
                Console.WriteLine($"{h.Name} gewinnt den Kampf!");
            }
            else if (s.Lebenspunkte > h.Lebenspunkte)
            {
                Console.WriteLine($"{s.Name} gewinnt den Kampf!");
            }
            else
            {
                Console.WriteLine("Der Kampf endet unentschieden!");
            }
        }
    }
}
