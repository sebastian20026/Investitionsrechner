﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Step2Coder6_A
{
    internal class Step2Coder6_A
    {
    }
}
