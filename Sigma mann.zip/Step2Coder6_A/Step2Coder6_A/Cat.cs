﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Step2Coder6_A
{
    internal class Cat
    {
        public string farbe;
        public int alter;
        public double weight;
        public bool is_friendly;
        public bool is_running;
        public string sigma;

        public static void schlafen()//methode ist eine funktion die sich innerhalb einer klasse befindet 
        {


        }

        

    }
}
