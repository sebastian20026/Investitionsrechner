﻿using System;

namespace Step2Coder6_A
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int zahl1; //Deklaration
            Kunde kunde1 = new Kunde(); //erzeugt mir einen neuen kunden, kunde1 ist ein objekt!!!!
            Kunde kunde2 = new Kunde();

            kunde1.name = "Hansi Hinterseer";
            kunde1.soz_nummer = "984 4495";

            kunde1.datenuebertrage(); //uber das objekt greife ich auf die methode datenuebertrage zu!!

            kunde2.geldeinzahlen();

            Console.WriteLine("wie heisst dein kunde");
            kunde1.name = Console.ReadLine();

            Console.WriteLine("wie lautet deine sozialverischerungsnummer");
            kunde1.soz_nummer = Console.ReadLine();

            Car car1 = new Car();
            Car car2 = new Car();

            car1.austattung = "vollaustattung";
            car2.austattung = "holz austattung";

            Console.WriteLine("Welche Austattung hast du");
            car1.austattung = Console.ReadLine();

            Console.WriteLine("Welche austattun hast du");
            car2.austattung = Console.ReadLine();

            car1.marke = "Bmw";
            car2.marke = "Porsche";


            Console.WriteLine("Welche Automarke magst du");
            car1.marke = Console.ReadLine();

            Console.WriteLine("Welche Automarke magst du");
            car2.marke = Console.ReadLine();


            Cat cat1 = new Cat();
            Cat cat2 = new Cat();

            cat1.is_friendly = true;
            cat2.farbe = "braun";

            Console.WriteLine("ist die katze freundlich");
            cat1.is_friendly =Convert.ToBoolean(Console.ReadLine());
            
            /*
            try
            {
            cat1.is_friendly = Convert.ToBoolean(Console.ReadLine());
            }
            catch (Exeption ex)
            {
                Console.WriteLine("Eingabe ungültig, wir setzen auf false");
                cat1.is_friendly = false;
            }
            
            string catinput = Console.ReadLine();
            if (catinput.ToLower() == "true")
            {
                cat1.is_friendly = true;
            }
            else if (catinput.ToLower() == "false")
            {
                cat1.is_friendly = false;
            }
            else
            {
                Console.WriteLine("Eingabe ungültig, wir setzen auf false");
                cat1.is_friendly = false;
            }
            Console.WriteLine($"{catinput}");
            Console.WriteLine("Welche farbe hat die katze"); */
        
if (catinput.ToLower() == "true")
{
    cat1.is_friendly = true;
}
else if (catinput.ToLower() == "false")
{
    cat1.is_friendly = false;
}
else
{
    Console.WriteLine("Eingabe ungültig, wir setzen auf false");
    cat1.is_friendly = false;
}

            Human human1 = new Human();
            Human human2 = new Human();



            human1.alter = 20;
            human1.hautfarbe = "weiß";
            human2.alter = 22;
            human2.hautfarbe = "Dunkel";

            Aktie aktie = new Aktie();
            Aktie Aktie2 = new Aktie();
            
            Haus haus1 = new Haus();
            Haus haus2 = new Haus();
            

            Console.WriteLine("Hello World!");


        }
    }
}
