﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Step2Coder6_A
{
    internal class Aktie
    {
        public  string aktien_name;
        private  double aktien_preis;
        public double marktkapitalisierung;
        private int aktien_anzahl;
        private int investoren;

        public static void aktiekaufen()//methode ist eine funktion die sich innerhalb einer klasse befindet 

        {


        }

        public static void aktieverkaufen()
        {


        }
    }
}
