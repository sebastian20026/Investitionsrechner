﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Step2Coder6_A
{
    internal class Kunde
    {

        public  string name; // Public 
        public static string firmen_status;
        public double konto_inhalt;
        public double zinssatz;
        public string soz_nummer;
        public bool super_costumer;
        public bool is_Boss;
        private string kundenkennwort; // private


        public  void datenuebertrage()//methode ist eine funktion die sich innerhalb einer klasse befindet 
        {
            Console.WriteLine("Name: "  + name + "Firmenstatus" + firmen_status);
        }

        public void geldeinzahlen() 
        { 

        }
    }
}
