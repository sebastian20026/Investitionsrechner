﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Step2Coder6_A
{
    internal class Haus
    {
        public int postleitzahl;

        public string straßenname;

        private double kaufpreis;

        private string grundbuch;

        public static void wohnen()//methode ist eine funktion die sich innerhalb einer klasse befindet 
        { 
        
        }
    }
}
