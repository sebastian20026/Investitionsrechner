﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Step2Coder6_A
{
    internal class Car
    {
        public int sitzplaetze;
        public double autopreis;
        public int ps;
        public int drehmoment;
        public string austattung;
        public string antriebsart;      //fuel 
        public string marke;

        public bool motor_lauft;
        public bool motor_ist_still;


        public static void fahren()//methode ist eine funktion die sich innerhalb einer klasse befindet 
        {

        }
    }
}
