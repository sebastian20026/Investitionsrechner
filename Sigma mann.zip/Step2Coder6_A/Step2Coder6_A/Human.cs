﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Step2Coder6_A
{
    internal class Human
    {
        public string name; //eigenschaften .. Attribute 
        public double weight;
        public double height;
        public string soz_nr;
        public string hautfarbe;
        public int alter;
        public string stark;
        public string augenfarbe;
        public bool is_alive;
        public bool is_running;

        public  void laufen() //methode ist eine funktion die sich innerhalb einer klasse befindet 
        {



        }

        public static void weinen()
        {

        }
    }
}
