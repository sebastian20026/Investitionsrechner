﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public class NumberListManager
{
    private List<int> numbers = new List<int>();

    public void AddNumber(int number)
    {
        numbers.Add(number);
    }

    public void RemoveNumber(int number)
    {
        numbers.Remove(number);
    }

    public double CalculateAverage()
    {
        if (numbers.Count == 0)
        {
            return 0;
        }
        return numbers.Average();
    }

    public double CalculateMedian()
    {
        if (numbers.Count == 0)
        {
            return 0;
        }

        numbers.Sort();
        int count = numbers.Count;
        if (count % 2 == 0)
        {
            return (numbers[count / 2 - 1] + numbers[count / 2]) / 2.0;
        }
        else
        {
            return numbers[count / 2];
        }
    }

    public void SaveToFile(string filename)
    {
        File.WriteAllLines(filename, numbers.Select(n => n.ToString()));
    }

    public void LoadFromFile(string filename)
    {
        if (File.Exists(filename))
        {
            var lines = File.ReadAllLines(filename);
            numbers = lines.Select(int.Parse).ToList();
        }
        else
        {
            Console.WriteLine("Datei nicht gefunden.");
        }
    }

    public void ShowMenu()
    {
        while (true)
        {
            Console.WriteLine("\n1. Nummer hinzufügen");
            Console.WriteLine("2. Nummer entfernen");
            Console.WriteLine("3. Durchschnitt berechnen");
            Console.WriteLine("4. Median berechnen");
            Console.WriteLine("5. Liste speichern");
            Console.WriteLine("6. Liste laden");
            Console.WriteLine("7. Aktuelle Liste anzeigen");
            Console.WriteLine("8. Beenden");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Write("Geben Sie eine Zahl ein: ");
                    int addNumber = int.Parse(Console.ReadLine());
                    AddNumber(addNumber);
                    break;
                case "2":
                    Console.Write("Geben Sie eine Zahl ein: ");
                    int removeNumber = int.Parse(Console.ReadLine());
                    RemoveNumber(removeNumber);
                    break;
                case "3":
                    double average = CalculateAverage();
                    Console.WriteLine($"Der Durchschnitt ist: {average}");
                    break;
                case "4":
                    double median = CalculateMedian();
                    Console.WriteLine($"Der Median ist: {median}");
                    break;
                case "5":
                    Console.Write("Dateiname zum Speichern: ");
                    string saveFileName = Console.ReadLine();
                    SaveToFile(saveFileName);
                    Console.WriteLine("Die Liste wurde gespeichert.");
                    break;
                case "6":
                    Console.Write("Dateiname zum Laden: ");
                    string loadFileName = Console.ReadLine();
                    LoadFromFile(loadFileName);
                    Console.WriteLine("Die Liste wurde geladen.");
                    break;
                case "7":
                    Console.WriteLine("Aktuelle Liste: " + string.Join(", ", numbers));
                    break;
                case "8":
                    Console.WriteLine("Programm beendet.");
                    return;
                default:
                    Console.WriteLine("Ungültige Auswahl. Bitte erneut versuchen.");
                    break;
            }
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        NumberListManager manager = new NumberListManager();
        manager.ShowMenu();
    }
}
