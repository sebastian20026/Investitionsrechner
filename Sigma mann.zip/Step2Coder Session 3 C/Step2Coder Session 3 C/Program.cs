﻿using System;

namespace WeatherApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string city = "Salzburg";

            try
            {
                WeatherData weatherData = GetMockWeatherData(city);

                Console.WriteLine($"Aktuelle Temperatur in {city}: {weatherData.Main.Temp}°C");
                Console.WriteLine($"Wetterbedingungen: {weatherData.Weather[0].Description}");

                double eveningTemperature = GetEveningTemperature(weatherData.Main.Temp);
                Console.WriteLine($"Vorhersage für den Abend: {eveningTemperature}°C");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Fehler beim Abrufen der Wetterdaten: {ex.Message}");
            }
        }

        static WeatherData GetMockWeatherData(string city)
        {
            // Mock-Wetterdaten für Salzburg
            WeatherData mockData = new WeatherData
            {
                Main = new MainData { Temp = 20.0 }, // Annahme: Temperatur von 20°C
                Weather = new Weather[] { new Weather { Description = "Sonnig" } } // Annahme: Sonniges Wetter
            };

            return mockData;
        }

        static double GetEveningTemperature(double currentTemperature)
        {
            // Annahme: Die Abendtemperatur ist 2 Grad kühler als die aktuelle Temperatur
            return currentTemperature - 2.0;
        }
    }

    // Klassen für die Wetterdaten
    public class WeatherData
    {
        public MainData Main { get; set; }
        public Weather[] Weather { get; set; }
    }

    public class MainData
    {
        public double Temp { get; set; }
    }

    public class Weather
    {
        public string Description { get; set; }
    }
}
