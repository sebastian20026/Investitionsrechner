﻿int auswahl; //int choice!

int fortnite_anzahl;

double fortnite_preis; // Deklaration

fortnite_preis = 22.54; //definition

int hannah_montana_anzahl;

double hannah_montana_preis;

hannah_montana_preis = 2.90;

int ok_anzahl;

double ok_preis;

ok_preis = 45.15;

int gute_nacht_anzahl;

double gute_nacht_preis;

gute_nacht_preis = 4545.45;




menue:
Console.WriteLine("willkommen - Drücken Sie 1 für fortnite oder 2 für hannah_montana oder Beenden mit 3");
auswahl = Convert.ToInt32(Console.ReadLine());
/*
switch(auswahl)
{
case 1:
      Console.WriteLine("wie viel fortnite magst du spielen? ");
        fortnite_anzahl = Convert.ToInt32(Console.ReadLine());
        fortnite_preis = fortnite_anzahl * fortnite_preis;
        Console.WriteLine("du musst bezahlen  " + fortnite_preis + " Euro\n");

        goto menue;
break;
        
case 2:
      Console.WriteLine("hannah_Montana tanz wie viele stunden?");
        hannah_montana_anzahl = Convert.ToInt32(Console.ReadLine());
        hannah_montana_preis = hannah_montana_anzahl * hannah_montana_preis;
        Console.WriteLine("du musst bezahlen  " + hannah_montana_preis + " Euro\n");
       
        goto menue;
        

case 3:
        Console.WriteLine("Beenden");
        goto menue;



break;
}
do
{

    Console.WriteLine("willkommen - Drücken Sie 1 für ok oder 2 für gutenacht oder Beenden mit 3");
    auswahl = Convert.ToInt32(Console.ReadLine());
*/
switch (auswahl)
 {
    case 1:
            Console.WriteLine("wie viel ok magst du sagen? ");
            ok_anzahl = Convert.ToInt32(Console.ReadLine());
            ok_preis = ok_anzahl * ok_preis;
            Console.WriteLine("du musst bezahlen  " + ok_preis + " Euro\n");

            
            break;

    case 2:
       Console.WriteLine("wie viel zahle ich für ein gute nacht?");
       gute_nacht_anzahl = Convert.ToInt32(Console.ReadLine());
       gute_nacht_preis = gute_nacht_anzahl * gute_nacht_preis;
       Console.WriteLine("du musst bezahlen  " + gute_nacht_preis + " Euro\n");
        break;

    case 3:
       Console.WriteLine("beenden");
       break;

    default:
        Console.WriteLine("Wiederholen Sie Ihre eingabe");
        break;

} while (auswahl !=3);