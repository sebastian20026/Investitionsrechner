﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Step2Coder7_klassen2
{
    internal class Car
    {   //Attribute 
        public string numberplate;
        public string model;
        public string farbe;
        public string produktionsnr;
        public double ps;
        public double gesamter_tankinhalt;
        public double derzeitiger_tankinhalt;
        public double kmh;

        //Konstruktor Constructor .... Initialisierung
        // immer einen Basiskonstruktor schreiben.. !!!!
       public Car() //Basiskonstruktor .. in den () ist es leer.. keine parameter
        {
            gesamter_tankinhalt= 100.00;
            produktionsnr = "A0000";
            ps = 0.0;
            farbe = "white";
            kmh = 0.0;
            derzeitiger_tankinhalt = 0.00;
            model = "S";

        }
        /*
        public Car(string _model, double _ps)
        {
            // Der Parameter '_model' wird dem Klassenattribut 'model' zugewiesen.
            model = _model; // Hier wird die lokale Kopie '_model' in das Attribut 'model' der Klasse kopiert und überschrieben.

            // Der Parameter '_ps' wird dem Klassenattribut 'ps' zugewiesen.
            ps = _ps;
            }
        */

        public Car(string model, double ps)
        {
            // Weist das Klassenattribut 'model' den Wert des übergebenen Parameters 'model' zu.
            this.model = model;

            // Weist das Klassenattribut 'ps' den Wert des übergebenen Parameters 'ps' zu.
            this.ps = ps;
        }

        //methoden
        public void fahren(double _geschwindkeit)
        {
            Console.WriteLine("wir fahren jetzt");
            Console.WriteLine("derzeit fahren wir " + kmh);
           Console.WriteLine("Wie schnell wollen Sie schneller fahren");
            
            kmh=Convert.ToDouble(Console.ReadLine());
            kmh = kmh + _geschwindkeit; 

            Console.WriteLine("derzeit fahren " + kmh);

        }


       public void tanken(double _liter)
        {
            Console.WriteLine("jetzt wird getankt"); //platzhalter
            Console.WriteLine("derzeitige´r tankinhalt vorher" +derzeitiger_tankinhalt);
            derzeitiger_tankinhalt = derzeitiger_tankinhalt + _liter;
            Console.WriteLine("derzeitger tankinhalt nachher" + derzeitiger_tankinhalt);

      
        }
    }


}
