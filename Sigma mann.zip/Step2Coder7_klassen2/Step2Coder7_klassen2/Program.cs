﻿using System;
using System.ComponentModel.Design;

namespace Step2Coder7_klassen2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Car car1 = new Car(); //hier wird objekt carl erzeugt
            Car car2 = new Car("Skoda Octavia Limo",78);
           // Car car3 = new Car("S464 WX", "BMW X1", 143,60.0,100.0);
            string antwort;
            double liter;
            double geschwindigkeit;
            Console.WriteLine("Wilkommen zur Auto dankenbank");

            Console.WriteLine("bitte kennzeichen eingeben");
            car1.numberplate =Console.ReadLine();

            // Console.WriteLine("wie gross ist ihr tank");
            car1.gesamter_tankinhalt = 100.00;

            Console.WriteLine("wie viel tank ist aktuell im tank drinnen");
            car1.derzeitiger_tankinhalt=Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Willst du tanken?");
            antwort = Console.ReadLine();

            if (antwort == "ja")
            {
                Console.WriteLine("Wie viel willst du tanken");
                liter= Convert.ToDouble(Console.ReadLine());

                car1.tanken(liter);
           
            }
            
            else
            {
                Console.WriteLine("dann tanken sie nicht");

            }

            Console.WriteLine("Wir Fahren jz");

            if (antwort == "ja")
            {
                Console.WriteLine("Wie schnell willst du fahren");
                geschwindigkeit = Convert.ToDouble(Console.ReadLine());

                car1.fahren(geschwindigkeit);
            }
            else
            {
               Console.WriteLine("dann halte an idiot");

            }




        }    
    }
}
