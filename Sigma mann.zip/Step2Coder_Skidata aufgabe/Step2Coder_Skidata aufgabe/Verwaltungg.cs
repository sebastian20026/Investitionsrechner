﻿using System.Collections.Generic;

namespace Step2Coder_Skidata
{
    public static class Verwaltungg
    {
        public static void MitarbeiterEinstellen(Boss boss, Mitarbeiter mitarbeiter)
        {
            boss.Einstellen(mitarbeiter);
        }

        public static void MitarbeiterLoeschen(Boss boss, Mitarbeiter mitarbeiter)
        {
            boss.Feuern(mitarbeiter);
        }

        public static void KundenAnzeigen(List<Kunde> kundenListe)
        {
            foreach (var kunde in kundenListe)
            {
                kunde.PrintData();
            }
        }
    }
}
