﻿using System;

namespace Step2Coder_Skidata
{
    public class Kunde
    {
        private string name;
        private string kundennummer;
        private double kontostand;
        private string adresse;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Kundennummer
        {
            get { return kundennummer; }
            set { kundennummer = value; }
        }

        public double Kontostand
        {
            get { return kontostand; }
            set { kontostand = value; }
        }

        public string Adresse
        {
            get { return adresse; }
            set { adresse = value; }
        }

        public Kunde() { }

        public Kunde(string name, string kundennummer, double kontostand, string adresse)
        {
            this.name = name;
            this.kundennummer = kundennummer;
            this.kontostand = kontostand;
            this.adresse = adresse;
        }

        public void GeldTransfer(double betrag)
        {
            kontostand += betrag;
            if (betrag > 0)
            {
                Console.WriteLine(betrag + " wurden dem Konto von " + name + " hinzugefuegt.");
            }
            else
            {
                Console.WriteLine(Math.Abs(betrag) + " wurden vom Konto von " + name + " abgehoben.");
            }
        }

        public void PrintData()
        {
            Console.WriteLine("Name: " + name + ", Kontostand: " + kontostand + ", Adresse: " + adresse);
        }
    }
}
