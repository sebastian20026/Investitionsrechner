﻿using System;
using System.Collections.Generic;

namespace Step2Coder_Skidata 
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Erstelle eine Boss-Instanz
            Boss boss = new Boss();

            // Füge initiale Mitarbeiter hinzu
            List<Mitarbeiter> initialeMitarbeiter = new List<Mitarbeiter>
            {
                new Mitarbeiter("Hansi"),
                new Mitarbeiter("Dieter"),
                new Mitarbeiter("Rudy"),
                new Mitarbeiter("Horst"),
                new Mitarbeiter("Manfred"),
                new Mitarbeiter("Gustav"),
                new Mitarbeiter("Peter"),
                new Mitarbeiter("Hans"),
                new Mitarbeiter("Klaus"),
                new Mitarbeiter("Fritz")
            };

            // Hinzufügen der initialen Mitarbeiter zur Liste
            foreach (var mitarbeiter in initialeMitarbeiter)
            {
                boss.MitarbeiterListe.Add(mitarbeiter);
            }

            // Test: Ausgabe der aktuellen Mitarbeiter
            Console.WriteLine("Aktuelle Mitarbeiter:");
            boss.MitarbeiterAusgeben();

            // Beispiel für Kundenhinzufügung und Anzeige
            List<Kunde> kundenListe = new List<Kunde>
            {
                new Kunde("Kunde1", "001", 5000, "Adresse1"),
                new Kunde("Kunde2", "002", 6000, "Adresse2")
            };

            Console.WriteLine("Kundenliste:");
            Verwaltungg.KundenAnzeigen(kundenListe);

            // Weitere Logik kann hier hinzugefügt werden...
        }
    }
}
