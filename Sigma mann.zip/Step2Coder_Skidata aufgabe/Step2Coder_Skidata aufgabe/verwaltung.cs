﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Finanzverwaltung
{
    public static class Verwaltung
    {
        public static void MitarbeiterEinstellen(Boss boss, Mitarbeiter mitarbeiter)
        {
            boss.Einstellen(mitarbeiter);
        }

        public static void MitarbeiterLoeschen(Boss boss, Mitarbeiter mitarbeiter)
        {
            boss.Feuern(mitarbeiter);
        }

        public static void KundeHinzufuegen(List<Kunde> kundenListe, Kunde kunde)
        {
            kundenListe.Add(kunde);
            Console.WriteLine($"{kunde.Name} wurde als Kunde hinzugefügt.");
        }

        public static void KundeLoeschen(List<Kunde> kundenListe, Kunde kunde)
        {
            if (kundenListe.Remove(kunde))
            {
                Console.WriteLine($"{kunde.Name} wurde aus der Kundenliste entfernt.");
            }
            else
            {
                Console.WriteLine($"{kunde.Name} ist nicht in der Liste.");
            }
        }

        public static void KundenAnzeigen(List<Kunde> kundenListe)
        {
            Console.WriteLine("Liste der Kunden:");
            foreach (var kunde in kundenListe)
            {
                kunde.PrintData();
            }
        }
    }
}
