﻿using System;

namespace Step2Coder_Skidata
{
    public class Mitarbeiter
    {
        private string name;
        private double kontostand;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public double Kontostand
        {
            get { return kontostand; }
            set { kontostand = value; }
        }

        public Mitarbeiter() { }

        public Mitarbeiter(string name)
        {
            this.name = name;
            kontostand = 0;
        }

        public void GeldTransfer(double betrag)
        {
            kontostand += betrag;
            if (betrag > 0)
            {
                Console.WriteLine(betrag + " wurden dem Konto von " + name + " hinzugefuegt.");
            }
            else
            {
                Console.WriteLine(Math.Abs(betrag) + " wurden vom Konto von " + name + " abgehoben.");
            }
        }

        public void PrintData()
        {
            Console.WriteLine("Name: " + name + ", Kontostand: " + kontostand);
        }
    }
}
