﻿using System;
using System.Collections.Generic;

namespace Step2Coder_Skidata
{
    public class Boss : Mitarbeiter
    {
        private List<Mitarbeiter> mitarbeiterListe = new List<Mitarbeiter>();

        public List<Mitarbeiter> MitarbeiterListe
        {
            get { return mitarbeiterListe; }
            set { mitarbeiterListe = value; }
        }

        public void Einstellen(Mitarbeiter mitarbeiter)
        {
            mitarbeiterListe.Add(mitarbeiter);
            Console.WriteLine("Mitarbeiter " + mitarbeiter.Name + " wurde eingestellt.");
        }

        public void Feuern(Mitarbeiter mitarbeiter)
        {
            mitarbeiterListe.Remove(mitarbeiter);
            Console.WriteLine("Mitarbeiter " + mitarbeiter.Name + " wurde gefeuert.");
        }

        public void MitarbeiterAusgeben()
        {
            foreach (var mitarbeiter in mitarbeiterListe)
            {
                mitarbeiter.PrintData();
            }
        }
    }
}
