﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface_step2coder23
{

    //interface ist ein grob vorlage.. alle attribute und methoden muessen dann in der abgeleitenn klassen
    //implementiret werden.
    internal interface IHuman
    {
        public string name { get; set; } // attribute name und automatisch mit einem getter und setter...
        public int alter {  get; set; }
        public void printdata() //in der abgeleiteten klasse muss die methode printdata ausimplementiert wetden.
        {


        }
    }
}
