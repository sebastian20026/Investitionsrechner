﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface_step2coder23
{
    internal class Mitarbeiter : IHuman
    {

        public string name { get; set; } // attribute name und automatisch mit einem getter und setter...
        public int alter { get; set; }
        public void printdata()
        { Console.WriteLine("der name ist" + name + "alter :" +alter);
            }
        
    }
}
