﻿using System;
using System.Threading.Tasks;

namespace Interface_step2coder23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Erstellung von Tasks 
         

            Kunde kunde1 = new Kunde("hansi hinterseer", 28,"salzburg",true);

            kunde1.printdata2();



        }
    }
}
