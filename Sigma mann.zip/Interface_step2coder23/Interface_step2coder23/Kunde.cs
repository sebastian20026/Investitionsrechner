﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface_step2coder23
{
    internal class Kunde:IHuman
    {
        private static int zaehler = 0;
        public string name { get; set; } // attribute name und automatisch mit einem getter und setter...
        public int alter { get; set; }

        public int kundenummer { get; set; }

        public string addresse { get; set; }

        public bool rassist { get; set; }
        public void printdata()
        { Console.WriteLine("der name ist"+ name +"alter :"+alter);
            }


        public Kunde()
        {
            
                }

        public Kunde(int kundenummer)
        {
            this.name = name;
            this.kundenummer = ++zaehler; // Zähler wird erhöht und als Kundennummer zugewiesen
            this.alter = alter;
            this.addresse = addresse;
            this.rassist = rassist;
        }

        public void printdata2()
        {
            Console.WriteLine("Wie heisst du: " + name + " Wie alt bist du: " + alter + " Wie lautet deine Kundennummer: " + kundenummer + " Bist du ein Rassist: " + rassist + " Wohnst du in Österreich: " + addresse);
        }


    }
}
