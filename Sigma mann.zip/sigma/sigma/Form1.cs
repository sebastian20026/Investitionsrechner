﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        TextBox txtInitialInvestment;
        TextBox txtMonthlyContribution;
        TextBox txtAnnualReturn;
        TextBox txtYears;
        Button btnCalculate;
        Label lblResult;
        Label lblInitialInvestment;
        Label lblMonthlyContribution;
        Label lblAnnualReturn;
        Label lblYears;

        public Form1()
        {
            InitializeComponent();
            InitializeFormComponents();
        }

        private void InitializeFormComponents()
        {
            // Überschrift hinzufügen
            Label lblTitle = new Label
            {
                Text = "Wie viel möchten Sie in den S&P 500 investieren?",
                AutoSize = true,
                Location = new Point(10, 10),
                Font = new Font("Arial", 12, FontStyle.Bold)
            };
            Controls.Add(lblTitle);

            // Label und TextBox für Anfangsinvestition
            lblInitialInvestment = new Label { Text = "Anfangsinvestition:", Location = new Point(10, 50), Size = new Size(160, 20) };
            Controls.Add(lblInitialInvestment);
            txtInitialInvestment = new TextBox { Location = new Point(180, 50), Width = 100 };
            Controls.Add(txtInitialInvestment);

            // Label und TextBox für monatliche Einzahlung
            lblMonthlyContribution = new Label { Text = "Monatliche Einzahlung:", Location = new Point(10, 80), Size = new Size(160, 20) };
            Controls.Add(lblMonthlyContribution);
            txtMonthlyContribution = new TextBox { Location = new Point(180, 80), Width = 100 };
            Controls.Add(txtMonthlyContribution);

            // Label und TextBox für jährliche Rendite
            lblAnnualReturn = new Label { Text = "Durchschnittliche Rendite (%):", Location = new Point(10, 110), Size = new Size(160, 20) };
            Controls.Add(lblAnnualReturn);
            txtAnnualReturn = new TextBox { Location = new Point(180, 110), Width = 100 };
            Controls.Add(txtAnnualReturn);

            // Label und TextBox für Anlagedauer
            lblYears = new Label { Text = "Anlagedauer (Jahre):", Location = new Point(10, 140), Size = new Size(160, 20) };
            Controls.Add(lblYears);
            txtYears = new TextBox { Location = new Point(180, 140), Width = 100 };
            Controls.Add(txtYears);

            // Button zum Berechnen
            btnCalculate = new Button { Text = "Berechnen", Location = new Point(100, 170) };
            btnCalculate.Click += new EventHandler(BtnCalculate_Click);
            Controls.Add(btnCalculate);

            // Label für Ergebnisanzeige
            lblResult = new Label { Text = "Das Ergebnis wird hier angezeigt.", Location = new Point(10, 200), Size = new Size(300, 20) };
            Controls.Add(lblResult);
        }

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double initialInvestment = double.Parse(txtInitialInvestment.Text);
                double monthlyContribution = double.Parse(txtMonthlyContribution.Text);
                double annualReturn = double.Parse(txtAnnualReturn.Text);
                double years = double.Parse(txtYears.Text);

                double monthlyRate = annualReturn / 100 / 12;
                double futureValue = initialInvestment;

                for (int month = 1; month <= years * 12; month++)
                {
                    futureValue = (futureValue + monthlyContribution) * (1 + monthlyRate);
                }

                lblResult.Text = $"Erwartetes Endkapital nach {years} Jahren: {futureValue:C2}";
            }
            catch (FormatException)
            {
                lblResult.Text = "Bitte geben Sie gültige Zahlen ein.";
            }
        }
    }
}
