﻿using System;

namespace Step2Coder_Virtualle_funktionen
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Erstellen von GameCharakter-Objekten
            GameCharakter gc1 = GameController.CreateGC("Hero", 1, 100, "Bravery");
            GameCharakter gc2 = GameController.CreateGC("Warrior", 2, 90, "Strength");

            // Erzeugen Batman-Objekt und Gegner-Objekt
            Batman batman = new Batman("Batman", 1, 100, "Detective Skills");
            Enemy enemy = new Enemy("Joker", 3, 70, "Chaos");

            string choice;
            do
            {
                Console.Clear();
                Console.WriteLine("Spielmenü:");
                Console.WriteLine("1. Kämpfe zwischen zwei Charakteren");
                Console.WriteLine("2. Charakterdaten anzeigen");
                Console.WriteLine("3. Programm beenden");
                Console.Write("Bitte wählen Sie eine Option (1-3): ");
                choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Clear();
                        if (gc1.Healthpoints > 0 && gc2.Healthpoints > 0)
                        {
                            GameController.Fight(gc1, gc2);
                        }
                        if (batman.Healthpoints > 0 && enemy.Healthpoints > 0)
                        {
                            GameController.Fight(batman, enemy);
                        }
                        break;

                    case "2":
                        Console.Clear();
                        gc1.PrintData();
                        gc2.PrintData();
                        batman.PrintData();
                        enemy.PrintData();
                        break;

                    case "3":
                        Console.WriteLine("Programm wird beendet.");
                        break;

                    default:
                        Console.WriteLine("Ungültige Eingabe, bitte versuchen Sie es erneut.");
                        break;
                }

                if (choice != "3")
                {
                    Console.WriteLine("\nDrücken Sie eine beliebige Taste, um zum Menü zurückzukehren...");
                    Console.ReadKey();
                }
            } while (choice != "3");
        }
    }
}
