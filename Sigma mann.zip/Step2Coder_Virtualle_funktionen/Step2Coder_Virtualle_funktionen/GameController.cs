﻿using System;

namespace Step2Coder_Virtualle_funktionen
{
    public static class GameController
    {
        // Statische Methode zur Erstellung eines GameCharakters
        public static GameCharakter CreateGC(string name, int id, int healthpoints, string specialability)
        {
            return new GameCharakter(name, id, healthpoints, specialability);
        }

        // Statische Methode für den Kampf
        public static void Fight(GameCharakter gc1, GameCharakter gc2)
        {
            if (gc1.Healthpoints > 0 && gc2.Healthpoints > 0)
            {
                gc1.Fight(gc1, gc2);
                if (gc2.Healthpoints > 0)
                {
                    gc2.Fight(gc2, gc1);
                }
            }
        }
    }
}
