﻿using System;

namespace Step2Coder_Virtualle_funktionen
{
    public class GameCharakter
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public int Healthpoints { get; set; }
        public string SpecialAbility { get; set; }

        // Basiskonstruktor
        public GameCharakter()
        {
            Name = "unknown";
            Id = 0;
            Healthpoints = 100;
            SpecialAbility = "none";
        }

        // Konstruktor mit Parametern
        public GameCharakter(string name, int id, int healthpoints, string specialability)
        {
            Name = name;
            Id = id;
            Healthpoints = healthpoints;
            SpecialAbility = specialability;
        }

        // Virtuelle Methode fight
        public virtual void Fight(GameCharakter gc1, GameCharakter gc2)
        {
            Console.WriteLine("GameCharakter is fighting");
        }

        // Methode zur Ausgabe der Daten
        public void PrintData()
        {
            Console.WriteLine($"Name: {Name}, ID: {Id}, Healthpoints: {Healthpoints}, Special Ability: {SpecialAbility}");
        }
    }
}
