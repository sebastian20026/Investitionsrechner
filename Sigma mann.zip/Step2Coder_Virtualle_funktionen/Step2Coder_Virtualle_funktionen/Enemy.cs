﻿using System;
using System.Xml.Linq;

namespace Step2Coder_Virtualle_funktionen
{
    public class Enemy : GameCharakter
    {
        // Zusätzliche Attribute können hier hinzugefügt werden

        // Basiskonstruktor
        public Enemy()
        {
            Name = "unknown enemy";
            Id = 2;
            Healthpoints = 100;
            SpecialAbility = "unknown ability";
        }

        // Konstruktor mit Parametern
        public Enemy(string name, int id, int healthpoints, string specialability) : base(name, id, healthpoints, specialability)
        {
        }

        // Überschreiben der virtuellen Methode fight
        public override void Fight(GameCharakter gc1, GameCharakter gc2)
        {
            if (gc2.Healthpoints <= 0)
            {
                Console.WriteLine($"{gc2.Name} is already defeated!");
                return;
            }

            Random rand = new Random();
            int damage = rand.Next(5, 20);
            gc2.Healthpoints -= damage;
            Console.WriteLine($"Enemy attacks and deals {damage} damage to {gc2.Name}. {gc2.Name}'s health is now {gc2.Healthpoints}.");

            if (gc2.Healthpoints <= 0)
            {
                Console.WriteLine($"{gc2.Name} has been defeated by Enemy!");
            }
        }
    }
}
