﻿using System;

namespace NeueFinanzverwaltung
{
    public class Kunde
    {
        public string Name { get; set; }
        public string Kundennummer { get; set; }
        private double Kontostand { get; set; }
        public string Adresse { get; set; }

        // Basiskonstruktor
        public Kunde()
        {
        }

        // Konstruktor mit Parametern
        public Kunde(string name, string kundennummer, double kontostand, string adresse)
        {
            Name = name;
            Kundennummer = kundennummer;
            Kontostand = kontostand;
            Adresse = adresse;
        }

        // Getter für Kontostand
        public double GetKontostand()
        {
            return Kontostand;
        }

        // Methode, um Geld hinzuzufügen oder abzuheben
        public void GeldTransfer(double amount)
        {
            if (amount > 0)
            {
                Kontostand += amount;
                Console.WriteLine($"{amount} wurde dem Kontostand von {Name} hinzugefügt.");
            }
            else if (amount < 0 && Kontostand + amount >= 0)
            {
                Kontostand += amount;
                Console.WriteLine($"{Math.Abs(amount)} wurde vom Kontostand von {Name} abgehoben.");
            }
            else
            {
                Console.WriteLine("Ungültiger Betrag.");
            }
        }

        // Zusätzliche Methode
        public void PrintInfo()
        {
            Console.WriteLine($"Name: {Name}, Kundennummer: {Kundennummer}, Kontostand: {Kontostand}, Adresse: {Adresse}");
        }
    }
}
