﻿using System;
using System.Collections.Generic;

namespace Aufgabenstellung
{
    public class Mitarbeiter
    {
        private string name;
        private double kontostand;

        public Mitarbeiter() { }

        public Mitarbeiter(string name)
        {
            this.name = name;
            kontostand = 0;
        }

        public string get_name()
        {
            return name;
        }

        public void set_name(string name)
        {
            this.name = name;
        }

        public double get_kontostand()
        {
            return kontostand;
        }

        public void set_kontostand(double kontostand)
        {
            this.kontostand = kontostand;
        }

        public void geld_transfer(double betrag)
        {
            kontostand += betrag;
            if (betrag > 0)
            {
                Console.WriteLine(betrag + " wurden dem Konto von " + name + " hinzugefügt.");
            }
            else
            {
                Console.WriteLine(Math.Abs(betrag) + " wurden vom Konto von " + name + " abgehoben.");
            }
        }

        public void print_data()
        {
            Console.WriteLine("Name: " + name + ", Kontostand: " + kontostand);
        }
    }

    public class Boss : Mitarbeiter
    {
        private List<Mitarbeiter> mitarbeiterListe = new List<Mitarbeiter>();

        public List<Mitarbeiter> get_mitarbeiterListe()
        {
            return mitarbeiterListe;
        }

        public void set_mitarbeiterListe(List<Mitarbeiter> mitarbeiterListe)
        {
            this.mitarbeiterListe = mitarbeiterListe;
        }

        public void einstellen(Mitarbeiter mitarbeiter)
        {
            mitarbeiterListe.Add(mitarbeiter);
            Console.WriteLine("Mitarbeiter " + mitarbeiter.get_name() + " wurde eingestellt.");
        }

        public void feuern(Mitarbeiter mitarbeiter)
        {
            mitarbeiterListe.Remove(mitarbeiter);
            Console.WriteLine("Mitarbeiter " + mitarbeiter.get_name() + " wurde entlassen.");
        }

        public void mitarbeiter_anzeigen()
        {
            foreach (var mitarbeiter in mitarbeiterListe)
            {
                mitarbeiter.print_data();
            }
        }
    }
}
