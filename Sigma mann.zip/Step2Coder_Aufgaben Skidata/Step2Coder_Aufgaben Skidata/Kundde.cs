﻿using System;

namespace Aufgabenstellung
{
    public class Kunde
    {
        private string name;
        private string kundennummer;
        private double kontostand;
        private string adresse;

        public Kunde() { }

        public Kunde(string name, string kundennummer, double kontostand, string adresse)
        {
            this.name = name;
            this.kundennummer = kundennummer;
            this.kontostand = kontostand;
            this.adresse = adresse;
        }

        public string get_name()
        {
            return name;
        }

        public void set_name(string name)
        {
            this.name = name;
        }

        public string get_kundennummer()
        {
            return kundennummer;
        }

        public void set_kundennummer(string kundennummer)
        {
            this.kundennummer = kundennummer;
        }

        public double get_kontostand()
        {
            return kontostand;
        }

        public void set_kontostand(double kontostand)
        {
            this.kontostand = kontostand;
        }

        public string get_adresse()
        {
            return adresse;
        }

        public void set_adresse(string adresse)
        {
            this.adresse = adresse;
        }

        public void geld_transfer(double betrag)
        {
            kontostand += betrag;
            if (betrag > 0)
            {
                Console.WriteLine(betrag + " wurden dem Konto von " + name + " hinzugefügt.");
            }
            else
            {
                Console.WriteLine(Math.Abs(betrag) + " wurden vom Konto von " + name + " abgehoben.");
            }
        }

        public void print_data()
        {
            Console.WriteLine("Name: " + name + ", Kontostand: " + kontostand + ", Adresse: " + adresse);
        }
    }
}
