﻿using Finanzverwaltung;
using System;
using System.Collections.Generic;

namespace Aufgabenstellung
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Erstelle eine Boss-Instanz
            Boss boss = new Boss();

            // Füge Anfangsmitarbeiter hinzu
            List<Mitarbeiter> initialMitarbeiter = new List<Mitarbeiter>
            {
                new Mitarbeiter("Hansi"),
                new Mitarbeiter("Dieter"),
                new Mitarbeiter("Rudy"),
                new Mitarbeiter("Horst"),
                new Mitarbeiter("Manfred"),
                new Mitarbeiter("Gustav"),
                new Mitarbeiter("Peter"),
                new Mitarbeiter("Hans"),
                new Mitarbeiter("Klaus"),
                new Mitarbeiter("Fritz")
            };

            foreach (var mitarbeiter in initialMitarbeiter)
            {
                boss.einstellen(mitarbeiter);
            }

            // Initialisiere die Kundenliste
            List<Kunde> kundenListe = new List<Kunde>
            {
                new Kunde("Customer1", "001", 5000, "Address1"),
                new Kunde("Customer2", "002", 6000, "Address2")
            };

            string choice;
            do
            {
                Console.WriteLine("\n=====================================");
                Console.WriteLine("Willkommen im Verwaltungssystem");
                Console.WriteLine("=====================================");
                Console.WriteLine("1. Mitarbeiter anzeigen");
                Console.WriteLine("2. Mitarbeiter einstellen");
                Console.WriteLine("3. Mitarbeiter entlassen");
                Console.WriteLine("4. Kunden anzeigen");
                Console.WriteLine("5. Kunden hinzufügen");
                Console.WriteLine("6. Kunden löschen");
                Console.WriteLine("7. Programm beenden");
                Console.WriteLine("=====================================");
                Console.Write("Bitte wählen Sie eine Option (1-7): ");
                choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        boss.mitarbeiter_anzeigen();
                        break;
                    case "2":
                        Console.Write("Geben Sie den Namen des neuen Mitarbeiters ein: ");
                        string newMitarbeiterName = Console.ReadLine();
                        Mitarbeiter newMitarbeiter = new Mitarbeiter(newMitarbeiterName);
                        boss.einstellen(newMitarbeiter);
                        break;
                    case "3":
                        Console.Write("Geben Sie den Namen des zu entlassenden Mitarbeiters ein: ");
                        string fireMitarbeiterName = Console.ReadLine();
                        Mitarbeiter mitarbeiterToFire = boss.get_mitarbeiterListe().Find(e => e.get_name() == fireMitarbeiterName);
                        if (mitarbeiterToFire != null)
                        {
                            boss.feuern(mitarbeiterToFire);
                        }
                        else
                        {
                            Console.WriteLine("Mitarbeiter nicht gefunden.");
                        }
                        break;
                    case "4":
                        Verwaltungg.kunden_anzeigen(kundenListe);
                        break;
                    case "5":
                        Console.Write("Geben Sie den Namen des neuen Kunden ein: ");
                        string customerName = Console.ReadLine();
                        Console.Write("Geben Sie die Kundennummer ein: ");
                        string customerNumber = Console.ReadLine();
                        Console.Write("Geben Sie den Kontostand ein: ");
                        double balance = Convert.ToDouble(Console.ReadLine());
                        Console.Write("Geben Sie die Adresse ein: ");
                        string address = Console.ReadLine();
                        kundenListe.Add(new Kunde(customerName, customerNumber, balance, address));
                        Console.WriteLine("Kunde erfolgreich hinzugefügt.");
                        break;
                    case "6":
                        Console.Write("Geben Sie die Kundennummer des zu löschenden Kunden ein: ");
                        string customerNumberToDelete = Console.ReadLine();
                        Kunde customerToDelete = kundenListe.Find(c => c.get_kundennummer() == customerNumberToDelete);
                        if (customerToDelete != null)
                        {
                            kundenListe.Remove(customerToDelete);
                            Console.WriteLine("Kunde erfolgreich gelöscht.");
                        }
                        else
                        {
                            Console.WriteLine("Kunde nicht gefunden.");
                        }
                        break;
                    case "7":
                        Console.WriteLine("Programm wird beendet.");
                        break;
                    default:
                        Console.WriteLine("Ungültige Eingabe, bitte versuchen Sie es erneut.");
                        break;
                }

                if (choice != "7")
                {
                    Console.WriteLine("\nDrücken Sie eine beliebige Taste, um zum Menü zurückzukehren...");
                    Console.ReadKey();
                }
            } while (choice != "7");
        }
    }
}
