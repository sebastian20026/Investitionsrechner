﻿using System;
using System.Collections.Generic;

namespace Finanzverwaltung
{
    public class Boss : Mitarbeiter
    {
        public List<Mitarbeiter> MitarbeiterListe { get; private set; }

        // Basiskonstruktor
        public Boss() : base()
        {
            MitarbeiterListe = new List<Mitarbeiter>();
        }

        // Konstruktor mit Parametern
        public Boss(string name, double kontostand) : base(name, kontostand)
        {
            MitarbeiterListe = new List<Mitarbeiter>();
        }

        // Methode, um einen Mitarbeiter einzustellen
        public void Einstellen(Mitarbeiter mitarbeiter)
        {
            MitarbeiterListe.Add(mitarbeiter);
            Console.WriteLine($"{mitarbeiter.Name} wurde eingestellt.");
        }

        // Methode, um einen Mitarbeiter zu feuern
        public void Feuern(Mitarbeiter mitarbeiter)
        {
            if (MitarbeiterListe.Remove(mitarbeiter))
            {
                Console.WriteLine($"{mitarbeiter.Name} wurde gefeuert.");
            }
            else
            {
                Console.WriteLine($"{mitarbeiter.Name} ist nicht in der Liste.");
            }
        }

        // Methode, um alle Mitarbeiter auszugeben
        public void MitarbeiterAusgeben()
        {
            Console.WriteLine("Liste der Mitarbeiter:");
            foreach (var mitarbeiter in MitarbeiterListe)
            {
                mitarbeiter.PrintInfo();
            }
        }
    }
}
