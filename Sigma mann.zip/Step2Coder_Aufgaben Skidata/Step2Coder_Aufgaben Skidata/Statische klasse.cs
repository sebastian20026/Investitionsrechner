﻿using System;

namespace NeueFinanzverwaltung
{
    public static class Finanzverwaltung
    {
        // Methode, um Geld von einem Mitarbeiter zu einem Kunden zu transferieren
        public static void Transfer(Mitarbeiter mitarbeiter, Kunde kunde, double amount)
        {
            if (mitarbeiter.GetKontostand() >= amount)
            {
                mitarbeiter.GeldTransfer(-amount);
                kunde.GeldTransfer(amount);
                Console.WriteLine($"{amount} wurde von {mitarbeiter.Name} zu {kunde.Name} transferiert.");
            }
            else
            {
                Console.WriteLine("Unzureichender Kontostand beim Mitarbeiter.");
            }
        }
    }
}
