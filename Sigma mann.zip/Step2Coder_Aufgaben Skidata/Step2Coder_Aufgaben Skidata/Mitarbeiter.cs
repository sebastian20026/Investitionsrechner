﻿using System;

namespace NeueFinanzverwaltung
{
    public class Mitarbeiter
    {
        public string Name { get; set; }
        public int SozVerNr { get; set; }
        private double Kontostand { get; set; }
        public int HierarchieLevel { get; set; }

        // Basiskonstruktor
        public Mitarbeiter()
        {
        }

        // Konstruktor mit Parametern
        public Mitarbeiter(string name, double kontostand)
        {
            Name = name;
            Kontostand = kontostand;
        }

        // Getter für Kontostand
        public double GetKontostand()
        {
            return Kontostand;
        }

        // Methode, um den Kontostand zu überprüfen
        public bool IsKontostandBelow(double amount)
        {
            return Kontostand < amount;
        }

        // Methode, um Geld hinzuzufügen oder abzuheben
        public void GeldTransfer(double amount)
        {
            if (amount > 0)
            {
                Kontostand += amount;
                Console.WriteLine($"{amount} wurde dem Kontostand von {Name} hinzugefügt.");
            }
            else if (amount < 0 && Kontostand + amount >= 0)
            {
                Kontostand += amount;
                Console.WriteLine($"{Math.Abs(amount)} wurde vom Kontostand von {Name} abgehoben.");
            }
            else
            {
                Console.WriteLine("Ungültiger Betrag.");
            }
        }

        // Zusätzliche Methode
        public void PrintInfo()
        {
            Console.WriteLine($"Name: {Name}, Sozialversicherungsnummer: {SozVerNr}, Kontostand: {Kontostand}, Hierarchie Level: {HierarchieLevel}");
        }
    }
}
