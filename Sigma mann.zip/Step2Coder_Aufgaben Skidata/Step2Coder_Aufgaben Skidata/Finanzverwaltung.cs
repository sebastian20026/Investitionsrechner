﻿using System;
using System.Collections.Generic;

namespace Aufgabenstellung
{
    public static class Verwaltungg
    {
        public static void einstellen(Boss boss, Mitarbeiter mitarbeiter)
        {
            boss.einstellen(mitarbeiter);
        }

        public static void feuern(Boss boss, Mitarbeiter mitarbeiter)
        {
            boss.feuern(mitarbeiter);
        }

        public static void kunden_anzeigen(List<Kunde> kundenListe)
        {
            foreach (var kunde in kundenListe)
            {
                kunde.print_data();
            }
        }
    }
}
