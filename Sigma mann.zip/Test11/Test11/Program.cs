﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace zahlenverwaltung
{
    public class zahlenlistenverwalter
    {
        private List<int> zahlen = new List<int>();

        public void zahl_hinzufuegen(int zahl)
        {
            zahlen.Add(zahl);
        }

        public void zahl_entfernen(int zahl)
        {
            zahlen.Remove(zahl);
        }

        public double berechne_durchschnitt()
        {
            if (zahlen.Count == 0)
                return 0;
            return zahlen.Average();
        }

        public double berechne_median()
        {
            if (zahlen.Count == 0)
                return 0;

            zahlen.Sort();
            int anzahl = zahlen.Count;
            if (anzahl % 2 == 0)
            {
                return (zahlen[anzahl / 2 - 1] + zahlen[anzahl / 2]) / 2.0;
            }
            else
            {
                return zahlen[anzahl / 2];
            }
        }

        public void speichere_in_datei(string dateiname)
        {
            File.WriteAllLines(dateiname, zahlen.Select(n => n.ToString()));
        }

        public void lade_aus_datei(string dateiname)
        {
            if (File.Exists(dateiname))
            {
                var zeilen = File.ReadAllLines(dateiname);
                zahlen = zeilen.Select(int.Parse).ToList();
            }
            else
            {
                Console.WriteLine("Datei nicht gefunden.");
            }
        }

        public void zeige_liste()
        {
            Console.WriteLine("Aktuelle Liste: " + string.Join(", ", zahlen));
        }

        public void zeige_menue()
        {
            while (true)
            {
                Console.WriteLine("\nWillkommen zum Zahlenverwaltungsprogramm!");
                Console.WriteLine("1. Nummer hinzufügen");
                Console.WriteLine("2. Nummer entfernen");
                Console.WriteLine("3. Durchschnitt berechnen");
                Console.WriteLine("4. Median berechnen");
                Console.WriteLine("5. Liste speichern");
                Console.WriteLine("6. Liste laden");
                Console.WriteLine("7. Aktuelle Liste anzeigen");
                Console.WriteLine("8. Beenden");

                string auswahl = Console.ReadLine();

                switch (auswahl)
                {
                    case "1":
                        Console.Write("Geben Sie eine Zahl ein: ");
                        int hinzufuegenZahl = int.Parse(Console.ReadLine());
                        zahl_hinzufuegen(hinzufuegenZahl);
                        break;
                    case "2":
                        Console.Write("Geben Sie eine Zahl ein: ");
                        int entfernenZahl = int.Parse(Console.ReadLine());
                        zahl_entfernen(entfernenZahl);
                        break;
                    case "3":
                        double durchschnitt = berechne_durchschnitt();
                        Console.WriteLine($"Der Durchschnitt ist: {durchschnitt}");
                        break;
                    case "4":
                        double median = berechne_median();
                        Console.WriteLine($"Der Median ist: {median}");
                        break;
                    case "5":
                        speichere_in_datei("zahlen.txt");
                        Console.WriteLine("Die Liste wurde gespeichert.");
                        break;
                    case "6":
                        lade_aus_datei("zahlen.txt");
                        Console.WriteLine("Die Liste wurde geladen.");
                        break;
                    case "7":
                        zeige_liste();
                        break;
                    case "8":
                        Console.WriteLine("Programm beendet.");
                        return;
                    default:
                        Console.WriteLine("Ungültige Auswahl. Bitte erneut versuchen.");
                        break;
                }
            }
        }
    }

    class programm
    {
        static void Main(string[] args)
        {
            zahlenlistenverwalter verwalter = new zahlenlistenverwalter();
            verwalter.zeige_menue();
        }
    }
}
